@echo off
rem COMET flight computer GUI launcher for Windows. Double-click to start.
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py -3
if not defined PY (
  where python >nul 2>nul && set PY=python
)
if not defined PY (
  echo Python 3 is not installed.
  echo Install it from https://www.python.org/downloads/  ^(tick "Add python.exe to PATH"^),
  echo then double-click this file again.
  start "" https://www.python.org/downloads/
  pause
  exit /b 1
)
%PY% -c "import serial" 2>nul || (
  echo Installing pyserial ^(one time^)...
  %PY% -m pip install --user pyserial
)
start "COMET" /min %PY% COMET_GUI.py
