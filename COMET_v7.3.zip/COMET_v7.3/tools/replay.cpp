// Bench replay: feeds a COMET CSV log (alt_m, accel, gyro) through
// SimpleRecoveryLogic + LandingDetector, then a synthetic flight.
// Build: g++ -std=c++17 -O1 replay.cpp -o replay && ./replay bench_log_2026-10-31.csv
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <random>
#include "../firmware/COMET_Firmware/SimpleRecoveryLogic.h"
#include "../firmware/COMET_Firmware/LandingDetector.h"
struct Row { uint32_t t; float alt, amag, gmax; bool force = false; };
static std::vector<Row> load(const char* p) {
  std::vector<Row> v; FILE* f = fopen(p, "r"); char line[512];
  if (!f || !fgets(line, sizeof line, f)) { fprintf(stderr, "cannot read %s\n", p); exit(1); }
  while (fgets(line, sizeof line, f)) {
    char* c[20]; int n = 0; c[n++] = line;
    for (char* q = line; *q && n < 20; q++) if (*q == ',') { *q = 0; c[n++] = q + 1; }
    float ax = atof(c[8]), ay = atof(c[9]), az = atof(c[10]);
    float g = fmaxf(fabsf(atof(c[11])), fmaxf(fabsf(atof(c[12])), fabsf(atof(c[13]))));
    v.push_back({(uint32_t)atol(c[0]), (float)atof(c[6]), sqrtf(ax*ax+ay*ay+az*az), g, !strcmp(c[2],"ASCENT") && atoi(c[5])==3});
  }
  return v;
}
static std::vector<Row> synth(bool machGlitch, float mainAlt) {
  // boost 2 s @ 6 g net, coast, drogue 20 m/s, main 5 m/s below mainAlt, 60 s on ground.
  // machGlitch: altitude reads 150 m low for 1 s, 2.4-3.4 s after launch
  // (transonic pressure disturbance) - looks like a sustained peak drop.
  std::vector<Row> v; std::mt19937 rng(3); std::normal_distribution<float> n(0, 0.4f), w(0, 0.15f);
  float alt = 0, vz = 0, rw = 0; bool apo = false, landed = false; uint32_t tl = 0;
  for (uint32_t i = 0; ; i++) {
    uint32_t t = 100000 + i * 100; float a = 0;
    if (i < 50) a = 0;                      // pad 5 s
    else if (i < 70) a = 60 - 9.81f * 0 ;   // boost
    else if (!apo) { a = -9.81f; if (vz < 0) { apo = true; printf("  [synthetic truth: apogee at t=%u alt=%.1f]\n", t, alt); } }
    if (apo && !landed) { float tgt = alt > mainAlt ? -20.f : -5.f; vz += (tgt - vz) * 0.3f; a = 0; }
    else vz += a * 0.1f;
    alt += vz * 0.1f;
    if (apo && alt <= 0 && !landed) { landed = true; alt = 0; vz = 0; tl = t; }
    rw = 0.95f * rw + w(rng);
    float amag = (i < 50 || landed) ? 1.04f : (i < 70 ? 7.0f : (apo ? 1.0f + 0.3f*sinf(i*0.7f) : 0.05f));
    float gm = landed ? 0.3f : (apo ? 40.f : 2.f);
    const float glitch = (machGlitch && i >= 75 && i < 85) ? -150.0f : 0.0f;
    v.push_back({t, alt + n(rng) + rw + glitch, amag, gm});
    if (landed && t - tl > 60000) break;
  }
  printf("  [synthetic truth: touchdown at t=%u]\n", tl);
  return v;
}
// lockoutMs: post-launch safety lockout. gateDetection=true is v7.1 (no
// detection inside the lockout); false mimics v6/v7 (detect, only delay firing).
static void run(const char* name, const std::vector<Row>& rows,
                uint32_t lockoutMs = 6000, float mainAlt = 200.0f, bool gateDetection = true) {
  printf("== %s ==\n", name);
  comet_recovery::Logic L; comet_land::Detector D;
  bool launched = false; uint32_t launchMs = 0;
  for (auto& r : rows) {
    if (r.force && !launched) { L.forceLaunch(L.filteredAGL); launched = true; launchMs = r.t; printf("  %u LAUNCH (forced, as in log)\n", r.t); }
    const bool inLockout = launched && r.t - launchMs < lockoutMs;
    auto res = L.update(r.t, r.alt, true, r.amag - 1.0f, true, mainAlt, !(gateDetection && inLockout));
    if (!launched && (res.launchAccel || res.launchBaro)) { launched = true; launchMs = r.t; printf("  %u LAUNCH (%s)\n", r.t, res.launchAccel ? "accel" : "baro"); }
    if (res.apogee) printf("  %u APOGEE method=%d filtAlt=%.1f max=%.1f  (+%.1f s after launch%s)\n", r.t,
                           (int)res.apogeeMethod, L.filteredAGL, L.maxAGL, (r.t - launchMs) / 1000.0f,
                           inLockout ? ", INSIDE lockout -> drogue queued, fires when lockout ends" : "");
    if (res.mainDue) { printf("  %u MAIN due alt=%.1f hard=%d\n", r.t, L.filteredAGL, res.hardFloorDue); L.markMainAccepted(); }
    if (launched && !D.landed) {
      auto why = D.update(r.t, launchMs, L.filteredAGL, true, r.amag, r.gmax, true);  // as the sketch: filtered alt
      if (why != comet_land::Reason::NONE) printf("  %u LANDED reason=%d spread=%.2f m\n", r.t, (int)why, D.lastSpreadM);
    }
  }
  if (!D.landed) printf("  never landed (last spread %.2f)\n", D.lastSpreadM);
}
int main(int argc, char** argv) {
  if (argc < 2) { fprintf(stderr, "usage: replay <log.csv>\n"); return 1; }
  run("bench log (accel-triggered launch, never moved)", load(argv[1]));
  run("synthetic ~850 m flight", synth(false, 200.0f));
  run("same flight, main set to 100 m", synth(false, 100.0f), 6000, 100.0f);
  auto glitch = synth(true, 200.0f);
  run("transonic glitch, OLD lockout (detect, delay firing)", glitch, 6000, 200.0f, false);
  run("transonic glitch, NEW lockout (no detection inside)", glitch, 6000, 200.0f, true);
}
