#!/bin/sh
# Builds the whole-firmware simulator: the real COMET_Firmware.ino compiled for
# the PC against simulated sensors, flash, UART and rocket physics (Linux/WSL).
cd "$(dirname "$0")" && g++ -std=gnu++17 -O1 -I. -I../../firmware/COMET_Firmware -Wno-unused-result \
  sim.cpp -o sim -Wl,--defsym=_FS_start=fs_sim_region -Wl,--defsym=_FS_end=fs_sim_region+16384
