#pragma once
#include <Arduino.h>
#include <map>
struct FSInfo { size_t totalBytes = 0, usedBytes = 0, blockSize = 4096, pageSize = 256, maxOpenFiles = 8, maxPathLength = 32; };
class LittleFSConfig { public: void setAutoFormat(bool) {} };
namespace simfs {
struct Entry { std::vector<uint8_t> data; size_t durable = 0; };  // durable = survives power loss
extern std::map<std::string, Entry> files;
extern bool formatted;
extern size_t total;
extern uint64_t flushes;
void markRegionFormatted();
}
class File {
  std::string path; size_t pos = 0; bool ok = false; bool append = false;
 public:
  File() {}
  File(const std::string& p, size_t start, bool app) : path(p), pos(start), ok(true), append(app) {}
  explicit operator bool() const { return ok; }
  size_t write(const uint8_t* b, size_t n) {
    if (!ok) return 0;
    auto& d = simfs::files[path].data;
    if (append) pos = d.size();
    if (pos + n > d.size()) {
      size_t oldBlocks = d.size() / 4096; d.resize(pos + n);
      if (d.size() / 4096 > oldBlocks) sim::advance_us(45000);   // block erase
    }
    memcpy(d.data() + pos, b, n); pos += n;
    return n;
  }
  size_t write(uint8_t c) { return write(&c, 1); }
  size_t read(uint8_t* b, size_t n) {
    if (!ok) return 0;
    auto& d = simfs::files[path].data;
    if (pos >= d.size()) return 0;
    n = std::min(n, d.size() - pos); memcpy(b, d.data() + pos, n); pos += n; return n;
  }
  int available() { return ok ? (int)(simfs::files[path].data.size() - std::min(pos, simfs::files[path].data.size())) : 0; }
  bool seek(uint32_t p) { pos = p; return true; }
  size_t size() { return ok ? simfs::files[path].data.size() : 0; }
  void flush() { if (ok) { simfs::files[path].durable = simfs::files[path].data.size(); simfs::flushes++; sim::advance_us(5000); } }
  void close() { flush(); ok = false; }
};
class LittleFSSim {
 public:
  void setConfig(const LittleFSConfig&) {}
  bool begin() { return simfs::formatted; }
  void end() {}
  bool format() { simfs::files.clear(); simfs::formatted = true; simfs::markRegionFormatted(); sim::advance_us(200000); return true; }
  bool exists(const char* p) { return simfs::files.count(p) > 0; }
  bool remove(const char* p) { return simfs::files.erase(p) > 0; }
  File open(const char* p, const char* mode) {
    std::string m(mode), s(p);
    bool exists = simfs::files.count(s) > 0;
    if ((m == "r" || m == "r+") && !exists) return File();
    if (m == "w" || m == "w+") { simfs::files[s].data.clear(); simfs::files[s].durable = 0; }
    if (!exists) simfs::files[s];
    return File(s, 0, m == "a");
  }
  bool info(FSInfo& i) {
    i.totalBytes = simfs::total; i.usedBytes = 8192;
    for (auto& f : simfs::files) i.usedBytes += (f.second.data.size() + 4095) / 4096 * 4096;
    return true;
  }
};
extern LittleFSSim LittleFS;
