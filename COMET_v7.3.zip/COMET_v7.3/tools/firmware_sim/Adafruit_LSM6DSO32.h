#pragma once
#include <Adafruit_Sensor.h>
enum { LSM6DSO32_ACCEL_RANGE_32_G = 3, LSM6DS_GYRO_RANGE_2000_DPS = 3, LSM6DS_RATE_104_HZ = 4 };
namespace sim { void imuSample(uint64_t us, float a[3], float gDps[3]); extern uint64_t imuReads; }
class Adafruit_LSM6DSO32 {
 public:
  bool begin_I2C(uint8_t) { return true; }
  void setAccelRange(int) {} void setGyroRange(int) {} void setAccelDataRate(int) {} void setGyroDataRate(int) {}
  void getEvent(sensors_event_t* a, sensors_event_t* g, sensors_event_t* t) {
    float acc[3], gy[3]; sim::imuSample(sim::now_us, acc, gy); sim::imuReads++;
    a->acceleration.x = acc[0]; a->acceleration.y = acc[1]; a->acceleration.z = acc[2];
    const float k = (float)(PI / 180.0);
    g->gyro.x = gy[0] * k; g->gyro.y = gy[1] * k; g->gyro.z = gy[2] * k;
    t->temperature = 27.0f;
    sim::advance_us(300);  // I2C burst cost
  }
};
