#pragma once
#include <Wire.h>
class Adafruit_MPL3115A2 { public: bool begin() { return true; } };
