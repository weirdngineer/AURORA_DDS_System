#pragma once
#include <Arduino.h>
namespace sim {
double baroAltitudeAbs(uint64_t us);   // what the MPL would measure now (m)
}
// Register-level MPL3115A2 (0x60) + LSM6DSO32 WHO_AM_I (0x6B).
class TwoWire {
  int addr = -1; std::vector<uint8_t> tx; std::deque<uint8_t> rx; uint8_t ptr[128] = {};
  uint8_t mpl[64] = {}; bool convActive = false; uint64_t convStartUs = 0;
  void mplService() {
    if (convActive && sim::now_us - convStartUs >= 66000ULL) {
      convActive = false;
      double alt = sim::baroAltitudeAbs(sim::now_us);
      int32_t v = (int32_t)lround(alt * 16.0);        // Q16.4, 20-bit signed
      uint32_t w = (uint32_t)(v << 12);
      mpl[0x01] = (w >> 24) & 0xFF; mpl[0x02] = (w >> 16) & 0xFF; mpl[0x03] = (w >> 8) & 0xF0;
      int16_t t = (int16_t)(26.5 * 16); uint16_t tw = (uint16_t)(t << 4);
      mpl[0x04] = tw >> 8; mpl[0x05] = tw & 0xF0;
      mpl[0x26] &= (uint8_t)~0x02;                     // OST self-clears
      mpl[0x06] |= 0x04; mpl[0x00] |= 0x04;            // PDR
    }
  }
 public:
  uint64_t mplReads = 0;
  void begin() {}
  void setClock(uint32_t) {}
  void beginTransmission(int a) { addr = a; tx.clear(); }
  size_t write(uint8_t b) { tx.push_back(b); return 1; }
  uint8_t endTransmission(bool = true) {
    if (addr != 0x60 && addr != 0x6B) return 2;
    if (tx.empty()) return 0;
    ptr[addr] = tx[0];
    if (addr == 0x60) {
      mplService();
      for (size_t i = 1; i < tx.size(); i++) {
        uint8_t r = (uint8_t)(tx[0] + i - 1);
        mpl[r] = tx[i];
        if (r == 0x26 && (tx[i] & 0x02)) { convActive = true; convStartUs = sim::now_us; }
      }
    }
    return 0;
  }
  uint8_t requestFrom(int a, int len) {
    rx.clear();
    if (a == 0x6B) { for (int i = 0; i < len; i++) rx.push_back(ptr[a] == 0x0F ? 0x6C : 0); return (uint8_t)len; }
    if (a != 0x60) return 0;
    mplService();
    uint8_t r = ptr[a];
    for (int i = 0; i < len; i++) rx.push_back(mpl[(uint8_t)(r + i)]);
    if (r == 0x01) { mpl[0x06] &= (uint8_t)~0x04; mpl[0x00] &= (uint8_t)~0x04; mplReads++; }
    return (uint8_t)len;
  }
  int available() { return (int)rx.size(); }
  int read() { if (rx.empty()) return -1; uint8_t b = rx.front(); rx.pop_front(); return b; }
};
extern TwoWire Wire;
