// End-to-end host simulation of COMET_Firmware.ino.
// Usage: sim <scenario> <fs_image>   (fs_image persists flash between "power cycles")
#include "COMET_Firmware.ino"
#include <random>
#include <fstream>
#include <functional>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <chrono>
#include <thread>

SerialUSBSim Serial; SerialUARTSim Serial1; TwoWire Wire; LittleFSSim LittleFS;
extern "C" { uint8_t fs_sim_region[16384]; }
namespace simfs { std::map<std::string, Entry> files; bool formatted = false; size_t total = 15u << 20; uint64_t flushes = 0;
  void markRegionFormatted() { memcpy(fs_sim_region + 8, "littlefs", 8); memset(fs_sim_region, 0, 8); } }

namespace sim {
uint64_t now_us = 0; std::vector<PinEvent> pinEvents; int pinState[64] = {}; int modeSwitch = HIGH;
int adcBattery = 2135;  // ~7.4 V through the 330k/100k divider
std::vector<ToneEvent> tones; uint64_t imuReads = 0;
std::mt19937 rng(7); std::normal_distribution<double> gauss(0, 1);

// ---------------- rocket ----------------
enum Phase { PAD, BOOST, COAST, DESCENT, LANDED };
Phase phase = PAD; double h = 0, v = 0; bool drogueOpen = false, mainOpen = false;
uint64_t ignitionUs = UINT64_MAX, bumpUs = UINT64_MAX, shakeFromUs = UINT64_MAX, shakeToUs = 0;
double padAsl = 312.0;
double shakeDiv = 4e4;   // sin(us/shakeDiv): 4e4 ~ 4 Hz fast shake, 1e5 ~ 1.6 Hz swinging
bool transonicGlitch = false; double apogeeH = 0; uint64_t apogeeUs = 0, touchdownUs = 0;
double boostAccel = 60.0; uint64_t boostUs = 2000000;
double wander = 0; uint64_t lastBaroUs = 0;
uint64_t physUs = 0;
void physics(uint64_t t) {
  while (physUs + 1000 <= t) {
    physUs += 1000; const double dt = 0.001;
    if (phase == PAD && physUs >= ignitionUs) phase = BOOST;
    if (phase == BOOST) { v += boostAccel * dt; if (physUs >= ignitionUs + boostUs) phase = COAST; }
    else if (phase == COAST || phase == DESCENT) {
      double target = mainOpen ? -5.0 : (drogueOpen ? -20.0 : -1e9);
      if (target > -1e8 && v < target + 50) v += (target - v) * std::min(1.0, 2.0 * dt) - (v > target ? 9.81 * dt : 0);
      else v -= 9.81 * dt;
      if (phase == COAST && v <= 0) { phase = DESCENT; apogeeH = h; apogeeUs = physUs; }
    }
    h += v * dt;
    if (phase == DESCENT && h <= 0) { h = 0; v = 0; phase = LANDED; touchdownUs = physUs; }
  }
}
void advance_us(uint64_t us) { now_us += us; physics(now_us); }
double trueAgl() { return h; }
double baroAltitudeAbs(uint64_t us) {
  if (us - lastBaroUs > 50000) { wander = 0.9 * wander + 0.12 * gauss(rng); lastBaroUs = us; }
  double weather = (double)us / 1e6 * (0.5 / 600.0);       // +0.5 m per 10 min drift
  double glitch = 0;
  if (transonicGlitch && us >= ignitionUs + 2400000 && us < ignitionUs + 3400000) glitch = -150;
  if (us >= shakeFromUs && us < shakeToUs) glitch += -1.5 + 1.2 * sin(us / 9e4);  // hand/pressure pulses (bench log: -2.5 m dips)
  return padAsl + weather + h + 0.30 * gauss(rng) + wander + glitch;
}
void imuSample(uint64_t us, float a[3], float g[3]) {
  double ax = -0.7, ay = -2.15, az = 9.98, sw = 0, gyro = 0.2;  // ~1.04 g, like the bench log
  bool bump = us >= bumpUs && us < bumpUs + 400000;
  if (phase == BOOST) { ax = 0; ay = 0; az = 9.81 + boostAccel; gyro = 3; }
  else if (phase == COAST) { ax = 0; ay = 0; az = -0.3; gyro = 5; }
  else if (phase == DESCENT) { ax = 0; ay = 0; az = (drogueOpen || mainOpen) ? 9.81 : 0.0; sw = 2.5; gyro = 35; }
  if (bump) { az += 22.0; ax += 8.0; gyro = 120; }
  if (us >= shakeFromUs && us < shakeToUs) { az += 25.0 * sin(us / shakeDiv); ax += 15.0 * cos(us / (shakeDiv * 1.25)); gyro = 200; }  // +-3 g shaking
  a[0] = (float)(ax + 0.15 * gauss(rng) + sw * sin(us / 3e5)); a[1] = (float)(ay + 0.15 * gauss(rng));
  a[2] = (float)(az + 0.15 * gauss(rng) + sw * cos(us / 4e5));
  for (int i = 0; i < 3; i++) g[i] = (float)(gyro * gauss(rng));
}
}  // namespace sim

void digitalWrite(int pin, int val) {
  if (pin >= 0 && pin < 64 && sim::pinState[pin] != val) {
    sim::pinState[pin] = val; sim::pinEvents.push_back({(uint32_t)millis(), pin, val});
    if (val == HIGH && pin == 3) sim::drogueOpen = true;   // the charge actually fires
    if (val == HIGH && pin == 2) sim::mainOpen = true;
  }
}

// ---------------- flash image persistence ----------------
void saveImage(const char* path, bool powerCut) {
  std::ofstream o(path, std::ios::binary);
  o.write((char*)&simfs::formatted, 1); o.write((char*)fs_sim_region, sizeof fs_sim_region);
  uint32_t n = (uint32_t)simfs::files.size(); o.write((char*)&n, 4);
  for (auto& f : simfs::files) {
    std::vector<uint8_t> d = f.second.data;
    if (powerCut) d.resize(std::min(d.size(), f.second.durable));  // unflushed data is lost
    uint32_t l = (uint32_t)f.first.size(), dl = (uint32_t)d.size();
    o.write((char*)&l, 4); o.write(f.first.data(), l); o.write((char*)&dl, 4); o.write((char*)d.data(), dl);
  }
}
bool loadImage(const char* path) {
  std::ifstream i(path, std::ios::binary); if (!i) return false;
  i.read((char*)&simfs::formatted, 1); i.read((char*)fs_sim_region, sizeof fs_sim_region);
  uint32_t n; i.read((char*)&n, 4);
  for (uint32_t k = 0; k < n; k++) {
    uint32_t l, dl; i.read((char*)&l, 4); std::string name(l, 0); i.read(&name[0], l);
    i.read((char*)&dl, 4); std::vector<uint8_t> d(dl); i.read((char*)d.data(), dl);
    simfs::files[name].data = d; simfs::files[name].durable = dl;
  }
  return true;
}

// ---------------- harness ----------------
int failures = 0;
void check(bool ok, const std::string& what) { printf("  [%s] %s\n", ok ? "PASS" : "FAIL", what.c_str()); if (!ok) failures++; }
uint64_t maxLoopGapUs = 0;
void runFor(double seconds, std::function<bool()> stop = nullptr) {
  uint64_t end = sim::now_us + (uint64_t)(seconds * 1e6);
  while (sim::now_us < end) {
    uint64_t t0 = sim::now_us; loop(); sim::advance_us(400);
    maxLoopGapUs = std::max(maxLoopGapUs, sim::now_us - t0);
    if (stop && stop()) break;
  }
}
size_t outMark = 0;
std::string sendCmd(const std::string& c, double settle = 0.3) {
  outMark = Serial.out.size();
  for (char ch : c) Serial.in.push_back(ch);
  Serial.in.push_back('\n');
  runFor(settle);
  return Serial.out.substr(outMark);
}
bool has(const std::string& hay, const std::string& needle) { return hay.find(needle) != std::string::npos; }
std::string lineWith(const std::string& hay, const std::string& needle) {
  size_t p = hay.find(needle); if (p == std::string::npos) return "";
  size_t a = hay.rfind('\n', p); a = a == std::string::npos ? 0 : a + 1;
  size_t b = hay.find('\r', p); return hay.substr(a, b - a);
}
int countPulses(int pin, uint32_t fromMs = 0) { int n = 0; for (auto& e : sim::pinEvents) if (e.pin == pin && e.value == HIGH && e.ms >= fromMs) n++; return n; }
uint32_t firstHigh(int pin, uint32_t fromMs = 0) { for (auto& e : sim::pinEvents) if (e.pin == pin && e.value == HIGH && e.ms >= fromMs) return e.ms; return 0; }
uint32_t pulseLen(int pin, uint32_t start) { for (auto& e : sim::pinEvents) if (e.pin == pin && e.value == LOW && e.ms >= start) return e.ms - start; return 0; }

// v7.3: a launch with no real climb runs the flight sequence at the end of the lockout.
void checkGroundSequence(uint32_t launchMs, const char* what) {
  uint32_t d = firstHigh(3, launchMs), m = firstHigh(2, launchMs);
  printf("  info: %s: drogue at +%.2f s, main at +%.2f s after launch\n", what,
         d ? (d - launchMs) / 1000.0 : -1.0, m ? (m - launchMs) / 1000.0 : -1.0);
  check(d && d - launchMs >= 6000 && d - launchMs < 6600, std::string(what) + ": drogue fires at the end of the 6 s lockout");
  check(m && m - d >= 3000 && m - d < 3400, std::string(what) + ": main fires 3 s (gap) after drogue");
  check(countPulses(3, launchMs) == 1 && countPulses(2, launchMs) == 1, std::string(what) + ": one pulse per channel");
}

void boot(const char* image) {
  memset(fs_sim_region, 0xFF, sizeof fs_sim_region);
  loadImage(image);
  setup();
}

// Flies one flight from the pad and returns once the board has logged a landing.
struct FlightResult { uint32_t launchMs, drogueMs, mainMs; double mainAgl; };
FlightResult fly(double padSeconds = 20) {
  runFor(padSeconds);
  sim::ignitionUs = sim::now_us;
  uint32_t ign = millis();
  double mainAgl = -1; uint32_t mainMs = 0;
  runFor(400, [&] {
    if (!mainMs && sim::pinState[2] == HIGH) { mainMs = millis(); mainAgl = sim::trueAgl(); }
    if (!mainMs && mainFired && !pyroOutputsLive()) { mainMs = millis(); mainAgl = sim::trueAgl(); }
    return sim::phase == sim::LANDED && !loggerActive && t_launch > 0;
  });
  runFor(5);
  return {ign, firstHigh(3, ign), mainMs, mainAgl};
}

int main(int argc, char** argv) {
  if (argc < 3) { fprintf(stderr, "usage: sim <scenario> <image>\n"); return 2; }
  std::string sc = argv[1]; const char* img = argv[2];
  printf("== scenario %s ==\n", sc.c_str());

  if (sc == "v5settings") {  // a board coming from v6 firmware (settings v5)
    memset(fs_sim_region, 0xFF, sizeof fs_sim_region);
    simfs::formatted = true; simfs::markRegionFormatted();
    CometSettings s{}; s.magic = SETTINGS_MAGIC; s.version = 5; s.mainAltMode = 2;
    for (int i = 0; i < 7; i++) { s.profiles[i] = flightProfiles[i]; s.profiles[i].flightLockoutMs = 10000; }
    s.profiles[0].timerEnabled = 1; s.profiles[1].flightLockoutMs = 4000; s.pyroArmed = 0;
    s.crc = settingsCrcCalc(s);
    auto& f = simfs::files["/comet_settings.bin"]; f.data.assign((uint8_t*)&s, (uint8_t*)&s + sizeof s); f.durable = f.data.size();
    saveImage(img, false);
    boot(img); runFor(2);
    check(rgbMode == 2, "active profile kept (YELLOW)");
    check(flightProfiles[0].timerEnabled == 3, "old single timer switch -> both timers on");
    check(flightProfiles[2].flightLockoutMs == 6000 && flightProfiles[1].flightLockoutMs == 4000, "10 s lockout -> 6 s, custom 4 s kept");
    check(pyroOutputsLive(), "older settings take release default LIVE");
    CometSettings r{}; auto& d = simfs::files["/comet_settings.bin"].data; memcpy(&r, d.data(), sizeof r);
    check(r.version == 6 && settingsValid(r), "settings re-saved as valid v6 while IDLE");
    saveImage(img, false);
  }
  else if (sc == "fresh") {
    boot(img);
    check(simfs::formatted, "blank storage auto-formatted on first boot");
    check(loggerMounted, "logger mounted");
    int longTones = 0; for (auto& t : sim::tones) if (t.freq == 6000) longTones++;
    check(longTones >= 3, "LIVE alarm (3 long high tones) at boot");
    std::string p = sendCmd("GETPARAMS");
    check(has(p, "PARAM FW_VERSION 7.3"), "FW_VERSION 7.3 reported");
    check(has(p, "PARAM PYRO_ENABLE 1"), "pyro outputs LIVE by default");
    std::string pl = sendCmd("PROFILE LIST");
    check(has(pl, "PROFILE VIOLET MAIN_ALT 200.000 ACCEL_ENABLE 1 DROGUE_TIMER_ENABLE 0 MAIN_TIMER_ENABLE 0 LOCKOUT_MS 6000"), "defaults: 200 m, timers off, 6 s lockout");
    std::string l = sendCmd("LIST");
    check(has(l, "COMET LOG ARCHIVE") && has(l, "STATIC SLOT 0"), "LIST works, ground session recording");
    std::string u = sendCmd("AT+CGMI");
    check(has(u, "ERR: unknown command 'AT+CGMI'") && !has(u, "rolling logger commands"), "unknown input -> one line, no help flood");
    std::string bad = sendCmd("PROFILE SET VIOLET MAIN_ALT 90");
    check(has(bad, "ERR"), "main 90 m rejected");
    std::string order = sendCmd("PROFILE SET RED DROGUE_TIMER_ENABLE 1 MAIN_TIMER_ENABLE 1 DROGUE_BACKUP_MS 20000 MAIN_BACKUP_MS 21000");
    check(has(order, "ERR") && (flightProfiles[0].timerEnabled == 0), "timer order violation rejected, profile unchanged");
    std::string okm = sendCmd("PROFILE SET RED MAIN_BACKUP_MS 30000 DROGUE_BACKUP_MS 20000 MAIN_TIMER_ENABLE 1 DROGUE_TIMER_ENABLE 1");
    check(has(okm, "OK PROFILE SET RED") && flightProfiles[0].timerEnabled == 3 && flightProfiles[0].mainBackupMs == 30000, "multi-field PROFILE SET in any order");
    sendCmd("PROFILE SET RED DROGUE_TIMER_ENABLE 0 MAIN_TIMER_ENABLE 0");
    std::string garbage(5000, 'x'); for (char ch : garbage) Serial.in.push_back(ch); runFor(0.5);
    check(true, "5000-byte line without newline handled (bounded buffer)");
    sendCmd("", 0.1);
    runFor(3);
    saveImage(img, false);
  }
  else if (sc == "flight" || sc == "glitch" || sc == "main100") {
    if (sc == "glitch") sim::transonicGlitch = true;
    boot(img);
    if (sc == "main100") { std::string r = sendCmd("PROFILE SET VIOLET MAIN_ALT 100"); check(has(r, "OK PROFILE SET VIOLET"), "set VIOLET main 100 m"); sendCmd("PROFILE APPLY VIOLET"); }
    runFor(5);
    // bench test before flight (pad check), without a power cycle afterwards
    std::string b = sendCmd("DROGUE", 1.0);
    uint32_t bt = firstHigh(3);
    check(bt > 0 && pulseLen(3, bt) >= 295 && pulseLen(3, bt) <= 320, "bench DROGUE test pulses 300 ms");
    check(!drogueFired && !mainFired, "bench test does not mark drogue as used");
    sim::drogueOpen = false;  // the test charge was not in the rocket
    double alt0 = alt_m;
    FlightResult f = fly(60);
    printf("  info: pad zero after 60 s idle: %.2f m (raw drift +%.2f m)\n", alt0, sim::now_us / 1e6 * 0.5 / 600);
    printf("  info: apogee %.1f m at +%.1f s; drogue at +%.2f s; main at %.1f m true AGL; touchdown +%.1f s\n",
           sim::apogeeH, (sim::apogeeUs / 1000 - f.launchMs) / 1000.0, (f.drogueMs - f.launchMs) / 1000.0, f.mainAgl,
           (sim::touchdownUs / 1000 - f.launchMs) / 1000.0);
    check(firstHigh(3, f.launchMs) == 0 || firstHigh(3, f.launchMs) - f.launchMs >= 6000, "nothing fires inside 6 s lockout");
    check(firstHigh(2, f.launchMs) == 0 || firstHigh(2, f.launchMs) - f.launchMs >= 6000, "main not inside lockout");
    double dApo = ((double)f.drogueMs - sim::apogeeUs / 1000.0) / 1000.0;
    check(f.drogueMs > 0 && dApo > -0.5 && dApo < 2.0, "drogue fires within 2 s after true apogee");
    check(countPulses(3, f.launchMs) == 1 && countPulses(2, f.launchMs) == 1, "exactly one drogue and one main pulse");
    double target = sc == "main100" ? 100 : 200;
    check(f.mainAgl > target - 25 && f.mainAgl < target + 5, "main fires near selected altitude");
    check(state == FlightState::LANDED && !loggerActive, "log closed and state LANDED after touchdown");
    check(Serial1.blockedUs == 0, "radio never blocked the loop");
    printf("  info: radio %llu lines, %llu bytes, dropped %lu; last radio line %zu chars\n", (unsigned long long)Serial1.lines,
           (unsigned long long)Serial1.bytesSent, (unsigned long)radioTxDropped, Serial1.lastLine.size());
    check(radioTxDropped == 0, "no radio packets dropped");
    printf("  info: IMU reads %.0f Hz average, max loop gap %.1f ms\n", sim::imuReads / (sim::now_us / 1e6), maxLoopGapUs / 1000.0);
    std::string l = sendCmd("LIST", 0.5);
    std::string row = lineWith(l, "* FLIGHT SLOT");
    printf("  info: %s\n", row.c_str());
    check(!row.empty() && has(row, "STATUS=2") && has(row, "MAXALT="), "LIST works after landing without RESET, stats present");
    double maxalt = atof(row.substr(row.find("MAXALT=") + 7).c_str());
    check(fabs(maxalt - sim::apogeeH) < 6, "MAXALT matches true apogee");
    std::string csv = sendCmd("DUMPCSV LASTFLIGHT", 2.0);
    size_t rows = 0, bad = 0; size_t p = 0;
    while ((p = csv.find("\n", p)) != std::string::npos) { p++; if (isdigit(csv[p])) { rows++; size_t e = csv.find('\n', p); std::string r = csv.substr(p, e - p); int commas = 0; size_t c = 0; for (int k = 0; k < 16; k++) { c = r.find(',', c) + 1; commas++; } if (r[c] != '1') bad++; } }
    check(has(csv, "BEGIN_CSV SLOT") && has(csv, "END_CSV SLOT") && rows > 500, "DUMPCSV complete (" + std::to_string(rows) + " rows)");
    check(bad == 0, "every CSV row has crc_ok=1 (" + std::to_string(bad) + " bad)");
    double maxv = atof(row.substr(row.find("MAXV=") + 5).c_str());
    check(sc == "glitch" || fabs(maxv - 120.0) < 12.0, "MAXV within 10% of true peak 120 m/s (got " + std::to_string(maxv) + ")");
    for (const char* ev : {"LAUNCH detected by accelerometer", "Safety lockout ended", "APOGEE confirmed", "DROGUE fired after apogee", "MAIN fired by altitude crossing", "Flight log ended"})
      check(has(csv, ev), std::string("log contains event: ") + ev);
    if (sc == "glitch") check(!has(csv.substr(0, csv.find("Safety lockout ended")), "APOGEE"), "transonic glitch inside lockout did not trigger apogee");
    std::string md = sendCmd("MARKDOWNLOADED " + std::to_string(latestStoredSlot(LOG_KIND_FLIGHT)));
    check(has(md, "OK: marked downloaded"), "MARKDOWNLOADED after landing");
    std::string s = sendCmd("SET PYRO_ENABLE 0");
    check(has(s, "locked during flight"), "settings stay locked until RESET");
    saveImage(img, false);
  }
  else if (sc == "barolaunch") {
    boot(img);
    std::string r = sendCmd("PROFILE SET VIOLET ACCEL_ENABLE 0");
    check(has(r, "OK PROFILE SET VIOLET") && !accelMethodsEnabled, "accelerometer launch detection off");
    FlightResult f = fly(10);
    printf("  info: launch detected %.2f s after ignition; apogee %.0f m; drogue +%.2f s after apogee\n",
           (t_launch - f.launchMs) / 1000.0, sim::apogeeH, (f.drogueMs - sim::apogeeUs / 1000.0) / 1000.0);
    check(t_launch > f.launchMs && t_launch - f.launchMs < 2000, "baro launch detected during boost");
    check(f.drogueMs > 0 && (f.drogueMs - sim::apogeeUs / 1000.0) < 2000, "drogue near apogee");
    check(f.mainAgl > 175 && f.mainAgl < 205, "main near 200 m");
    std::string l = sendCmd("LIST", 0.5);
    std::string row = lineWith(l, "* FLIGHT SLOT");
    check(fabs(atof(row.substr(row.find("MAXALT=") + 7).c_str()) - sim::apogeeH) < 6, "MAXALT zeroed to the pad even though launch was seen late");
    sendCmd("RESET"); sendCmd("PROFILE SET VIOLET ACCEL_ENABLE 1"); runFor(2);
    saveImage(img, false);
  }
  else if (sc == "lowflight" || sc == "lowflight_tuned") {
    sim::boostUs = 600000;  // short burn: ~77 m apogee 4.3 s after launch, below the 200 m main altitude
    boot(img);
    if (sc == "lowflight_tuned") {  // small-motor settings: lockout = burn + ~1 s, short drogue->main gap
      std::string r = sendCmd("PROFILE SET VIOLET LOCKOUT_MS 2000 DROGUE_MAIN_GAP_MS 1000");
      check(has(r, "OK PROFILE SET VIOLET"), "lockout 2 s, drogue->main gap 1 s");
    }
    FlightResult f = fly(10);
    double drogueAgl = -1;  // true AGL at drogue: rerun-free estimate from pin time is not stored; print timing instead
    (void)drogueAgl;
    printf("  info: apogee %.1f m at +%.1f s; drogue +%.2f s after apogee; main %.2f s after drogue at %.1f m true AGL\n",
           sim::apogeeH, (sim::apogeeUs / 1000.0 - f.launchMs) / 1000.0, (f.drogueMs - sim::apogeeUs / 1000.0) / 1000.0,
           (f.mainMs - f.drogueMs) / 1000.0, f.mainAgl);
    check(f.drogueMs > 0 && f.mainMs > 0, "both channels fire on a flight below the main altitude");
    if (sc == "lowflight") {
      printf("  NOTE: apogee falls inside the 6 s lockout, so recovery is late (main at %.1f m). Expected with a\n"
             "        6 s lockout on a small motor; tune LOCKOUT/GAP per motor (see lowflight_tuned).\n", f.mainAgl);
    } else {
      check(f.drogueMs - sim::apogeeUs / 1000.0 < 1500, "drogue within 1.5 s of apogee with tuned lockout");
      check(f.mainAgl > 30, "main opens well above the ground with tuned settings");
      sendCmd("RESET"); sendCmd("PROFILE SET VIOLET LOCKOUT_MS 6000 DROGUE_MAIN_GAP_MS 3000"); runFor(2);
    }
    sendCmd("RESET"); runFor(2);
    saveImage(img, false);
  }
  else if (sc == "hop") {
    sim::boostUs = 200000; sim::boostAccel = 40;  // ~3 m hop: never clears 10 m
    boot(img);
    FlightResult f = fly(10);
    printf("  info: hop apogee %.1f m\n", sim::apogeeH);
    check(t_launch > 0, "launch detected");
    checkGroundSequence(t_launch, "hop below 10 m");
    check(!loggerActive, "log closed");
    sendCmd("RESET"); runFor(2);
    saveImage(img, false);
  }
  else if (sc == "nostorage") {   // old/foreign data in the FS region: must NOT auto-format
    memset(fs_sim_region, 0xFF, sizeof fs_sim_region); fs_sim_region[100] = 0x12;
    simfs::formatted = false;
    setup();
    check(!loggerMounted, "non-blank unreadable storage is not auto-formatted");
    std::string p = sendCmd("GETPARAMS");
    check(has(p, "PARAM STORAGE_OK 0"), "GETPARAMS reports STORAGE_OK 0");
    std::string l = sendCmd("LIST");
    check(has(l, "LOGGER ERROR: LittleFS mount failed"), "LIST reports the storage error (GUI offers format)");
    std::string f = sendCmd("FORMATFS CONFIRM", 1.0);
    check(loggerMounted && has(f, "OK: entire filesystem formatted"), "FORMATFS CONFIRM fixes it");
  }
  else if (sc == "interactive") {  // real-time board on a pseudo-terminal for GUI tests
    double duration = argc > 3 ? atof(argv[3]) : 120;
    int m = posix_openpt(O_RDWR | O_NOCTTY); grantpt(m); unlockpt(m);
    const char* slave = ptsname(m);
    int sfd = open(slave, O_RDWR | O_NOCTTY); termios t; tcgetattr(sfd, &t); cfmakeraw(&t); tcsetattr(sfd, TCSANOW, &t);
    fcntl(m, F_SETFL, O_NONBLOCK);
    printf("PTY %s\n", slave); fflush(stdout);
    boot(img);
    size_t sent = 0; auto t0 = std::chrono::steady_clock::now(); uint64_t sim0 = sim::now_us;
    if (getenv("SIM_LAUNCH_AT")) sim::ignitionUs = UINT64_MAX;
    while (true) {
      double wall = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
      if (wall > duration) break;
      char buf[512]; ssize_t n;
      while ((n = read(m, buf, sizeof buf)) > 0) for (ssize_t i = 0; i < n; i++) Serial.in.push_back(buf[i]);
      while ((double)(sim::now_us - sim0) / 1e6 < wall) { loop(); sim::advance_us(400); }
      while (sent < Serial.out.size()) {
        ssize_t w = write(m, Serial.out.data() + sent, std::min<size_t>(4096, Serial.out.size() - sent));
        if (w <= 0) break; sent += (size_t)w;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    saveImage(img, false);
    close(sfd); close(m);
  }
  else if (sc == "forcelaunch") {   // GUI "Force Launch" on the bench
    boot(img);
    runFor(5);
    std::string r = sendCmd("LAUNCH");
    check(t_launch > 0 && state == FlightState::ASCENT_LOCKOUT, "LAUNCH command enters lockout");
    uint32_t t0 = millis();
    runFor(60, [&] { return !loggerActive; });
    double closedAfter = (millis() - t_launch) / 1000.0;
    printf("  info: log closed %.1f s after forced launch\n", closedAfter);
    check(!loggerActive && state == FlightState::LANDED, "bench forced launch closes the log and shows LANDED");
    check(closedAfter >= 30.0 && closedAfter < 32.0, "still board: log closes right after the 30 s minimum");
    checkGroundSequence(t_launch, "forced launch");
    std::string csv = sendCmd("DUMPCSV LASTFLIGHT", 1.5);
    for (const char* ev : {"LAUNCH forced", "Safety lockout ended", "No climb after launch", "DROGUE fired after apogee", "MAIN fired by altitude crossing", "Flight log ended"})
      check(has(csv, ev), std::string("log contains: ") + ev);
    sendCmd("RESET"); runFor(1);
    saveImage(img, false);
  }
  else if (sc == "shake" || sc == "swing") {   // pop-test style handling with flight settings
    if (sc == "swing") sim::shakeDiv = 1e5;
    boot(img);
    check(pyroOutputsLive(), "flight configuration: outputs LIVE");
    runFor(15);
    uint32_t s0 = millis(); sim::shakeFromUs = sim::now_us; sim::shakeToUs = sim::now_us + 3000000;
    runFor(3.5);
    if (t_launch) printf("  info: launch detected %.2f s into the shake (state %s)\n", (t_launch - s0) / 1000.0, stateStr(state));
    else printf("  info: NO launch detected (state %s)\n", stateStr(state));
    uint32_t tl = t_launch;
    runFor(60, [&] { return !loggerActive; });
    if (tl) {
      printf("  info: log closed at +%.1f s after launch; state %s\n", (millis() - tl) / 1000.0, stateStr(state));
      check((millis() - tl) >= 30000, "log at least 30 s long");
    }
    if (tl) checkGroundSequence(tl, sc == "swing" ? "swinging launch" : "shake launch");
    else check(countPulses(2, s0) == 0 && countPulses(3, s0) == 0, "no launch -> no charge fired");
    std::string l = sendCmd("LIST", 0.5);
    std::string row = lineWith(l, "* FLIGHT SLOT");
    printf("  info: %s\n", row.c_str());
    std::string csv = sendCmd("DUMPCSV LASTFLIGHT", 1.5);
    size_t rows = 0, p = 0; while ((p = csv.find("\n", p)) != std::string::npos) { p++; if (isdigit(csv[p])) rows++; }
    printf("  info: CSV rows %zu (10 s pre-launch + shake + settle); events:\n", rows);
    for (const char* ev : {"LAUNCH detected", "Safety lockout ended", "APOGEE", "DROGUE fired", "MAIN fired", "Flight log ended"})
      printf("        %-24s %s\n", ev, has(csv, ev) ? "yes" : "no");
    // shake again without reset/power cycle
    uint32_t s2 = millis(); sim::shakeFromUs = sim::now_us; sim::shakeToUs = sim::now_us + 3000000;
    runFor(20);
    printf("  info: second shake after LANDED: t_launch changed=%s, new log=%s, state %s\n",
           t_launch != tl ? "yes" : "no", loggerActive ? "yes" : "no", stateStr(state));
    check(countPulses(2, s2) == 0 && countPulses(3, s2) == 0, "second shake after LANDED fires nothing (needs RESET/power cycle)");
    // keep handling it for a long time: log stays open while it moves?
    std::string r = sendCmd("RESET"); runFor(5);
    uint32_t s3 = millis(); sim::shakeFromUs = sim::now_us; sim::shakeToUs = sim::now_us + 40000000;
    runFor(42); uint32_t tl3 = t_launch;
    bool openWhileMoving = loggerActive;
    printf("  info: 40 s of continuous handling: launch %s, log still open at end of handling=%s\n",
           tl3 ? ("at +" + std::to_string((tl3 - s3) / 1000.0) + " s").c_str() : "not detected", loggerActive ? "yes" : "no");
    runFor(60, [&] { return !loggerActive; });
    if (tl3) printf("  info: ... log closed %.1f s after launch (handling lasted 40 s)\n", (millis() - tl3) / 1000.0);
    if (tl3) {
      check(openWhileMoving || (millis() - tl3) >= 30000, "log stays open at least 30 s");
      checkGroundSequence(tl3, "40 s of handling");
    }
  }
  else if (sc == "poptest_log") {   // is a GUI Test Drogue/Main recorded anywhere?
    boot(img);
    runFor(5);
    sendCmd("DROGUE", 1.0); runFor(4); sendCmd("MAIN", 1.0); runFor(4);
    std::string c = sendCmd("STATICCSV LASTSTATIC", 1.0);
    size_t rows = 0, p = 0, pyroRows = 0;
    while ((p = c.find("\n", p)) != std::string::npos) { p++; if (isdigit(c[p])) { rows++; size_t e = c.find('\n', p); std::string r = c.substr(p, e - p);
      int f = atoi(r.substr(r.find(',', r.find(',', r.find(',') + 1) + 1) + 1).c_str()); if (f & 8) pyroRows++; } }
    printf("  info: ground-session log rows %zu, rows with pyro-active flag %zu, test-fire note present: %s\n",
           rows, pyroRows, has(c, "fired by serial test command") ? "yes" : "no");
  }
  else if (sc == "bump_timers") {
    boot(img);
    std::string r = sendCmd("PROFILE SET VIOLET DROGUE_TIMER_ENABLE 1 MAIN_TIMER_ENABLE 1 DROGUE_BACKUP_MS 8000 MAIN_BACKUP_MS 12000");
    check(has(r, "OK PROFILE SET VIOLET"), "both timers enabled (8 s / 12 s)");
    sendCmd("PROFILE APPLY VIOLET");
    runFor(10);
    sim::bumpUs = sim::now_us; uint32_t bm = millis();
    runFor(3);
    check(t_launch > 0, "pad bump detected as launch (expected)");
    check(state == FlightState::ASCENT_LOCKOUT, "state ASCENT_LOCKOUT after bump");
    uint32_t tl = t_launch;
    runFor(60);
    checkGroundSequence(tl, "pad bump with timers on");
    (void)bm;
    check(!loggerActive && state == FlightState::LANDED, "log closed on the pad, state LANDED");
    std::string rs = sendCmd("RESET");
    check(state == FlightState::IDLE && t_launch == 0, "RESET returns to IDLE");
    sendCmd("PROFILE SET VIOLET DROGUE_TIMER_ENABLE 0 MAIN_TIMER_ENABLE 0"); runFor(2);
    saveImage(img, false);
  }
  else if (sc == "timers_flight") {   // baro apogee + timers on: timers must not double-fire
    boot(img);
    sendCmd("PROFILE SET VIOLET DROGUE_TIMER_ENABLE 1 MAIN_TIMER_ENABLE 1 DROGUE_BACKUP_MS 20000 MAIN_BACKUP_MS 60000");
    sendCmd("PROFILE APPLY VIOLET");
    FlightResult f = fly(10);
    check(countPulses(3, f.launchMs) == 1 && countPulses(2, f.launchMs) == 1, "one drogue + one main with timers also on");
    check(f.drogueMs - f.launchMs < 20000, "baro apogee drogue came before the 20 s timer");
    sendCmd("RESET"); sendCmd("PROFILE SET VIOLET DROGUE_TIMER_ENABLE 0 MAIN_TIMER_ENABLE 0"); runFor(2);
    saveImage(img, false);
  }
  else if (sc == "safe_set") {
    boot(img);
    std::string r = sendCmd("SET PYRO_ENABLE 0");
    check(has(r, "PYRO OUTPUTS SAFE"), "SET PYRO_ENABLE 0 accepted");
    runFor(2);
    saveImage(img, false);
  }
  else if (sc == "safe_flight") {
    boot(img);
    int longTones = 0; for (auto& t : sim::tones) if (t.freq == 6000) longTones++;
    check(longTones == 0, "no LIVE alarm when SAFE");
    std::string p = sendCmd("GETPARAMS");
    check(has(p, "PARAM PYRO_ENABLE 0"), "SAFE persisted across power cycle");
    FlightResult f = fly(5);
    check(countPulses(2) == 0 && countPulses(3) == 0, "SAFE: MOSFET pins never switched");
    check(drogueFired && mainFired, "SAFE: logic still ran drogue and main decisions");
    sendCmd("RESET"); sendCmd("SET PYRO_ENABLE 1"); runFor(2);
    check(pyroOutputsLive(), "SET PYRO_ENABLE 1 makes outputs LIVE again");
    saveImage(img, false);
  }
  else if (sc == "powercut") {
    boot(img);
    runFor(10); sim::ignitionUs = sim::now_us; uint32_t ign = millis();
    runFor(60, [&] { return sim::phase == sim::DESCENT && sim::h < 400; });
    uint32_t cut = millis();
    printf("  info: power cut %.1f s after launch at %.0f m\n", (cut - ign) / 1000.0, sim::h);
    saveImage(img, true);
    // second process run boots from this image
  }
  else if (sc == "recover") {
    boot(img);
    std::string l = sendCmd("LIST", 0.5);
    std::string row = lineWith(l, "* FLIGHT SLOT");
    printf("  info: %s\n", row.c_str());
    long secs = atol(row.substr(row.find("SECONDS=") + 8).c_str());
    check(has(row, "STATUS=2") && has(row, "MAXALT="), "interrupted flight recovered as Saved with stats");
    check(secs >= 20, "at most ~2 s lost at the power cut (flushed every 2 s)");
    saveImage(img, false);
  }
  else { fprintf(stderr, "unknown scenario\n"); return 2; }
  printf("  -> %s (%d failure%s)\n", failures ? "FAILED" : "ok", failures, failures == 1 ? "" : "s");
  return failures ? 1 : 0;
}
