#!/bin/sh
# Whole-firmware simulation suite (Linux/WSL). Builds the simulator, then flies
# every scenario; the flash image carries over between simulated power cycles.
cd "$(dirname "$0")" || exit 1
./build.sh || exit 1
rm -f img.bin img100.bin v5.bin ns.bin; fail=0
run() { ./sim "$1" "$2" > "log_$1.txt" 2>&1 || fail=1; grep -E "==|FAIL|info|NOTE|        6 s|->" "log_$1.txt"; }
run fresh img.bin; run flight img.bin; run glitch img.bin
cp img.bin img100.bin; run main100 img100.bin
for s in barolaunch lowflight lowflight_tuned hop forcelaunch swing shake bump_timers timers_flight safe_set safe_flight powercut recover; do run $s img.bin; done
run v5settings v5.bin; run nostorage ns.bin
echo "TOTAL PASS: $(cat log_*.txt | grep -c PASS)  FAIL: $(cat log_*.txt | grep -c FAIL)"; exit $fail
