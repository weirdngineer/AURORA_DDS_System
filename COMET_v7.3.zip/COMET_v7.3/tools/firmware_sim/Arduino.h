// Host-side stand-in for the Arduino-Pico core, for simulating COMET on a PC.
#pragma once
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
#include <deque>
#include <algorithm>
#include <climits>
using std::isnan; using std::isinf;

#define PI 3.14159265358979323846
#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define A2 28
#define HEX 16
#define DEC 10
typedef uint8_t byte;

namespace sim {
extern uint64_t now_us;
void advance_us(uint64_t us);
struct PinEvent { uint32_t ms; int pin; int value; };
extern std::vector<PinEvent> pinEvents;
extern int pinState[64];
extern int modeSwitch;      // digitalRead value of the MODE pin
extern int adcBattery;      // raw 12-bit count
struct ToneEvent { uint32_t ms; unsigned freq; };
extern std::vector<ToneEvent> tones;
}
inline unsigned long millis() { return (unsigned long)(uint32_t)(sim::now_us / 1000ULL); }
inline void delay(unsigned long ms) { sim::advance_us((uint64_t)ms * 1000ULL); }
inline void delayMicroseconds(unsigned int us) { sim::advance_us(us); }
inline void pinMode(int, int) {}
void digitalWrite(int pin, int v);
inline int digitalRead(int) { return sim::modeSwitch; }
inline int analogRead(int) { return sim::adcBattery; }
inline void analogWrite(int, int) {}
inline void analogReadResolution(int) {}
inline void tone(int, unsigned f) { sim::tones.push_back({(uint32_t)millis(), f}); }
inline void noTone(int) {}
inline bool isDigit(char c) { return c >= '0' && c <= '9'; }

class String {
  std::string s;
 public:
  String(const char* c = "") : s(c ? c : "") {}
  String(const std::string& x) : s(x) {}
  String(char c) : s(1, c) {}
  unsigned length() const { return (unsigned)s.size(); }
  const char* c_str() const { return s.c_str(); }
  char operator[](unsigned i) const { return i < s.size() ? s[i] : 0; }
  String& operator+=(char c) { s += c; return *this; }
  String& operator+=(const char* c) { s += c; return *this; }
  String& operator+=(const String& o) { s += o.s; return *this; }
  bool operator==(const char* c) const { return s == c; }
  bool operator==(const String& o) const { return s == o.s; }
  bool operator!=(const char* c) const { return s != c; }
  void trim() {
    size_t a = s.find_first_not_of(" \t\r\n"); if (a == std::string::npos) { s.clear(); return; }
    size_t b = s.find_last_not_of(" \t\r\n"); s = s.substr(a, b - a + 1);
  }
  void toUpperCase() { for (auto& ch : s) ch = (char)toupper((unsigned char)ch); }
  String substring(unsigned from) const { return from >= s.size() ? String("") : String(s.substr(from)); }
  String substring(unsigned from, unsigned to) const {
    if (from > to) std::swap(from, to);
    if (from >= s.size()) return String("");
    if (to > s.size()) to = (unsigned)s.size();
    return String(s.substr(from, to - from));
  }
  int indexOf(char c) const { size_t p = s.find(c); return p == std::string::npos ? -1 : (int)p; }
  int indexOf(char c, unsigned from) const { size_t p = s.find(c, from); return p == std::string::npos ? -1 : (int)p; }
  bool startsWith(const String& p) const { return s.compare(0, p.s.size(), p.s) == 0; }
  bool endsWith(const String& p) const { return s.size() >= p.s.size() && s.compare(s.size() - p.s.size(), p.s.size(), p.s) == 0; }
  long toInt() const { return atol(s.c_str()); }
  float toFloat() const { return (float)atof(s.c_str()); }
};

class Print {
 public:
  virtual ~Print() {}
  virtual size_t write(uint8_t c) = 0;
  virtual size_t write(const uint8_t* b, size_t n) { for (size_t i = 0; i < n; i++) write(b[i]); return n; }
  size_t print(const char* c) { return write((const uint8_t*)c, strlen(c)); }
  size_t print(const String& x) { return print(x.c_str()); }
  size_t print(char c) { return write((uint8_t)c); }
  size_t num(unsigned long long v, int base, bool neg) {
    char b[70]; int i = 69; b[i] = 0;
    if (v == 0) b[--i] = '0';
    while (v) { int d = (int)(v % base); b[--i] = (char)(d < 10 ? '0' + d : 'A' + d - 10); v /= base; }
    if (neg) b[--i] = '-';
    return print(b + i);
  }
  size_t print(unsigned char v, int base = DEC) { return num(v, base, false); }
  size_t print(int v, int base = DEC) { return v < 0 && base == 10 ? num((unsigned long long)(-(long long)v), 10, true) : num((unsigned)v, base, false); }
  size_t print(unsigned v, int base = DEC) { return num(v, base, false); }
  size_t print(long v, int base = DEC) { return v < 0 && base == 10 ? num((unsigned long long)(-(long long)v), 10, true) : num((unsigned long)v, base, false); }
  size_t print(unsigned long v, int base = DEC) { return num(v, base, false); }
  size_t print(double v, int digits = 2) { char b[64]; snprintf(b, sizeof b, "%.*f", digits, v); return print(b); }
  size_t println() { return print("\r\n"); }
  template <typename T> size_t println(const T& v) { size_t n = print(v); return n + println(); }
  template <typename T> size_t println(const T& v, int f) { size_t n = print(v, f); return n + println(); }
};

class Stream : public Print {
 public:
  virtual int available() = 0;
  virtual int read() = 0;
};

class SerialUSBSim : public Stream {
 public:
  std::string out;            // everything the firmware printed
  std::deque<char> in;        // bytes the "PC" sent
  void begin(unsigned long) {}
  explicit operator bool() const { return true; }
  size_t write(uint8_t c) override { out += (char)c; return 1; }
  using Print::write;
  int available() override { return (int)in.size(); }
  int read() override { if (in.empty()) return -1; char c = in.front(); in.pop_front(); return (uint8_t)c; }
};

// Models the RP2040 UART: 32-byte TX FIFO drained at baud/10 bytes per second.
class SerialUARTSim : public Stream {
 public:
  uint32_t baud = 57600;
  double fifo = 0;            // bytes currently in the FIFO
  uint64_t lastUs = 0;
  uint64_t bytesSent = 0;
  uint64_t blockedUs = 0;     // time the firmware spent blocked in write()
  std::string line, lastLine; uint64_t lines = 0;
  void setTX(int) {}
  void setRX(int) {}
  void begin(uint32_t b) { baud = b; lastUs = sim::now_us; }
  void drain() {
    double gone = (double)(sim::now_us - lastUs) * baud / 10.0 / 1e6;
    lastUs = sim::now_us; fifo = std::max(0.0, fifo - gone);
  }
  int availableForWrite() { drain(); return fifo <= 31.0 ? 1 : 0; }
  size_t write(uint8_t c) override {
    drain();
    if (fifo > 31.0) {  // real uart_putc_raw blocks here until a slot frees
      uint64_t wait = (uint64_t)((fifo - 31.0) * 10.0 * 1e6 / baud) + 1;
      blockedUs += wait; sim::advance_us(wait); drain();
    }
    fifo += 1; bytesSent++;
    if (c == '\n') { lastLine = line; line.clear(); lines++; } else if (c != '\r') line += (char)c;
    return 1;
  }
  using Print::write;
  int available() override { return 0; }
  int read() override { return -1; }
};

extern SerialUSBSim Serial;
extern SerialUARTSim Serial1;
