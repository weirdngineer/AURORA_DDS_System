#!/bin/sh
# COMET flight computer GUI launcher for Linux.
#   ./start_comet_gui_linux.sh           start the GUI
#   ./start_comet_gui_linux.sh --setup   one-time: USB permission rule (needs sudo)
cd "$(dirname "$0")" || exit 1
if [ "$1" = "--setup" ]; then
  sudo cp linux/99-comet-rp2040.rules /etc/udev/rules.d/ &&
  sudo udevadm control --reload-rules && sudo udevadm trigger &&
  echo "USB rule installed. Unplug and replug the flight computer."
  python3 -c "import tkinter" 2>/dev/null || echo "Also install Tk:  sudo apt install python3-tk"
  exit 0
fi
python3 -c "import tkinter" 2>/dev/null || { echo "Install Tk first:  sudo apt install python3-tk"; exit 1; }
if ! python3 -c "import serial" 2>/dev/null; then
  echo "Installing pyserial (one time)..."
  python3 -m pip install --user pyserial 2>/dev/null ||
  python3 -m pip install --user --break-system-packages pyserial 2>/dev/null ||
  { echo "Could not install pyserial. Try:  sudo apt install python3-serial"; exit 1; }
fi
exec python3 COMET_GUI.py "$@"
