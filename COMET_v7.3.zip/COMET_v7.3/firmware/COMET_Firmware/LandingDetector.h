#pragma once
// COMET landing / "log can close" detector. No pins, sensor calls or heap.
// Why not |vz| < threshold: on the bench log the baro velocity never stayed
// under 1 m/s for more than 5.9 s while the board sat perfectly still, so a
// vz dwell kept resetting and the flight log never finished.
//
// Instead, work on 1-second bucket MEANS (averages out the sample noise) and
// require the spread of the last 5 bucket means to be small. Stationary bench
// data: worst spread 1.05 m. Slowest realistic main descent (3 m/s) spreads
// ~12 m over the same window, so 2.0 m cleanly separates the two.
// The IMU confirms: magnitude ~1 g and steady, low rotation. Freefall/coast
// reads ~0 g, so IMU stillness cannot be satisfied in the air either.
#include <math.h>
#include <stdint.h>

namespace comet_land {

constexpr uint32_t BUCKET_MS = 1000;
constexpr uint8_t WINDOW_BUCKETS = 5;          // baro spread window (5 s)
constexpr float BARO_SPREAD_MAX_M = 2.0f;
constexpr float ACCEL_MAG_TOL_G = 0.20f;       // |a| within 1 g +/- this
constexpr float ACCEL_SPAN_MAX_G = 0.15f;      // max-min |a| inside a bucket
constexpr float GYRO_MAX_DPS = 20.0f;
constexpr uint8_t MIN_BARO_SAMPLES = 5;        // per bucket, else bucket invalid
constexpr uint8_t CONFIRM_BARO_IMU = 3;        // consecutive still buckets (baro+IMU)
constexpr uint8_t CONFIRM_BARO_ONLY = 20;      // rocket rocking in wind / IMU bad
// Every flight log runs at least this long after launch, however still the
// board is; it runs longer while motion continues.
constexpr uint32_t MIN_FLIGHT_LOG_MS = 30000;
// Last-resort close so a log can never stay "Recording" forever. Size this to
// your flash: at 10 Hz, 20 min = 12000 records.
constexpr uint32_t MAX_FLIGHT_LOG_MS = 20UL * 60UL * 1000UL;

enum class Reason : uint8_t { NONE, STILL_BARO_IMU, STILL_BARO_ONLY, TIMEOUT };

class Detector {
public:
  bool landed = false;
  Reason reason = Reason::NONE;
  float lastSpreadM = 0;   // for logging / tuning
  uint8_t stillBuckets = 0;

  void reset() { *this = Detector(); }

  // Call every loop after launch has been detected.
  //   altM      : filtered or raw baro altitude (either works; means are used)
  //   accelMagG : sqrt(ax^2+ay^2+az^2) in g
  //   gyroMaxDps: max(|gx|,|gy|,|gz|)
  Reason update(uint32_t now, uint32_t launchMs,
                float altM, bool newBaro,
                float accelMagG, float gyroMaxDps, bool newImu) {
    if (landed) return Reason::NONE;
    if (!started) { bucketStart = now; started = true; }

    if (newBaro && isfinite(altM)) { baroSum += altM; ++baroN; }
    if (newImu && isfinite(accelMagG) && isfinite(gyroMaxDps)) {
      if (imuN == 0) { aMin = aMax = accelMagG; gMax = gyroMaxDps; }
      else {
        if (accelMagG < aMin) aMin = accelMagG;
        if (accelMagG > aMax) aMax = accelMagG;
        if (gyroMaxDps > gMax) gMax = gyroMaxDps;
      }
      ++imuN;
    }

    const uint32_t sinceLaunch = now - launchMs;
    if (sinceLaunch >= MAX_FLIGHT_LOG_MS) return finish(Reason::TIMEOUT);
    if ((uint32_t)(now - bucketStart) < BUCKET_MS) return Reason::NONE;

    closeBucket();
    bucketStart = now;
    if (validCount < WINDOW_BUCKETS) {
      stillBuckets = stillImuBuckets = 0;
      return Reason::NONE;
    }

    float lo = means[0], hi = means[0];
    for (uint8_t i = 1; i < WINDOW_BUCKETS; i++) {
      if (means[i] < lo) lo = means[i];
      if (means[i] > hi) hi = means[i];
    }
    lastSpreadM = hi - lo;
    const bool baroStill = lastSpreadM <= BARO_SPREAD_MAX_M;
    if (!baroStill) { stillBuckets = stillImuBuckets = 0; return Reason::NONE; }

    if (stillBuckets < 255) ++stillBuckets;
    if (lastImuStill) { if (stillImuBuckets < 255) ++stillImuBuckets; }
    else stillImuBuckets = 0;

    // Stillness keeps counting during the minimum, so a board that is already
    // at rest closes right at 30 s instead of starting its count then.
    if (sinceLaunch < MIN_FLIGHT_LOG_MS) return Reason::NONE;
    if (stillImuBuckets >= CONFIRM_BARO_IMU) return finish(Reason::STILL_BARO_IMU);
    if (stillBuckets >= CONFIRM_BARO_ONLY) return finish(Reason::STILL_BARO_ONLY);
    return Reason::NONE;
  }

private:
  bool started = false;
  uint32_t bucketStart = 0;
  float baroSum = 0; uint16_t baroN = 0;
  float aMin = 0, aMax = 0, gMax = 0; uint16_t imuN = 0;
  float means[WINDOW_BUCKETS] = {};
  uint8_t head = 0, validCount = 0;
  bool lastImuStill = false;
  uint8_t stillImuBuckets = 0;

  void closeBucket() {
    if (baroN >= MIN_BARO_SAMPLES) {
      means[head] = baroSum / baroN;
      head = (uint8_t)((head + 1) % WINDOW_BUCKETS);
      if (validCount < WINDOW_BUCKETS) ++validCount;
    } else {
      validCount = 0;  // baro gap: restart the window rather than trust stale data
    }
    lastImuStill = imuN > 0 &&
                   fabsf(0.5f * (aMin + aMax) - 1.0f) <= ACCEL_MAG_TOL_G &&
                   (aMax - aMin) <= ACCEL_SPAN_MAX_G &&
                   gMax <= GYRO_MAX_DPS;
    baroSum = 0; baroN = 0; imuN = 0;
  }
  Reason finish(Reason r) { landed = true; reason = r; return r; }
};

} // namespace comet_land
