#pragma once
// COMET simple recovery decision logic (no Arduino dependencies).
// Decision logic only: this module never touches hardware pins. Verified by
// tools/replay.cpp and the whole-firmware simulator in tools/firmware_sim.
#include <stdint.h>
#include <math.h>
#include "AltitudeFilter.h"

namespace comet_recovery {

// Lowest main altitude any profile may select (profiles default to 200 m).
// Fixed here, NOT editable by profiles/serial.
constexpr float MAIN_ABSOLUTE_FLOOR_M = 100.0f;
constexpr float BARO_LAUNCH_RISE_M = 30.0f;
constexpr uint32_t BARO_LAUNCH_DWELL_MS = 200;
constexpr float ACCEL_LAUNCH_DELTA_G = 1.2f;
constexpr uint32_t ACCEL_LAUNCH_DWELL_MS = 100;
constexpr float APOGEE_DROP_M = 3.0f;
constexpr uint32_t APOGEE_DROP_DWELL_MS = 600;
// Barometric altitude velocity: positive ascent -> negative descent.
// Equivalent to pressure trend changing negative -> positive.
constexpr float RISING_VZ_MPS = 1.0f;
constexpr float FALLING_VZ_MPS = -1.0f;
constexpr uint32_t REVERSAL_DWELL_MS = 250;
constexpr uint32_t FLOOR_CROSS_DWELL_MS = 200;
constexpr float FLOOR_CROSS_MIN_PEAK_M = 3.0f;
constexpr uint32_t BARO_FRESH_MAX_MS = 350;
constexpr uint32_t ACCEL_FRESH_MAX_MS = 150;
// Climb that separates a real flight from a launch detected on the ground.
// Barometric apogee needs the peak to clear it (baro noise must never fake an
// apogee). If a launch was detected but the peak is still below it when the
// lockout ends (pop test, bumped pad, hop), the flight sequence runs anyway:
// drogue at the end of the lockout, main after the drogue->main gap.
constexpr float MIN_APOGEE_AGL_M = 10.0f;
// vz must stay above RISING_VZ_MPS this long before ascent counts as "seen".
constexpr uint32_t ASCENT_SEEN_DWELL_MS = 300;

// These are the ONLY four operating states (BOOT/FAULT handled by main sketch).
enum class Phase : uint8_t { PAD, ASCENT, DESCENT, DONE };
enum class ApogeeMethod : uint8_t { NONE, PEAK_DROP, VZ_REVERSAL, NO_CLIMB };
struct Result {
  bool launchAccel = false;
  bool launchBaro = false;
  bool apogee = false;
  ApogeeMethod apogeeMethod = ApogeeMethod::NONE;
  bool drogueDue = false;
  bool mainDue = false;
  bool hardFloorDue = false;
};

class Logic {
public:
  Phase phase = Phase::PAD;
  float filteredAGL = 0.0f;
  float maxAGL = 0.0f;
  float velocityMps = 0.0f;
  bool seenAscent = false;
  bool mainAccepted = false;
  float peakSinceLaunch = 0.0f;  // includes the lockout, unlike maxAGL

  static float target(float programmed) {
    return (isfinite(programmed) && programmed > MAIN_ABSOLUTE_FLOOR_M)
      ? programmed : MAIN_ABSOLUTE_FLOOR_M;
  }

  void reset() { *this = Logic(); }

  // detectAllowed=false is the post-launch safety lockout: altitude and vz
  // keep tracking, but no peak is latched and no apogee/main dwell can start,
  // so transonic baro spikes or a bumped launch can never queue a deployment
  // that would fire the instant the lockout ends.
  Result update(uint32_t now, float baroAGL, bool newBaro,
                float accelDeltaG, bool newAccel, float programmedMain,
                bool detectAllowed = true) {
    Result r;
    bool baroValid = newBaro && isfinite(baroAGL);
    if (baroValid) {
      // Feed RAW baro AGL here. Altitude and vz come from one alpha-beta
      // filter; do not pre-filter in the sketch or the lag stacks.
      const float dtS = altReady ? (uint32_t)(now - lastBaroMs) / 1000.0f : 0.1f;
      lastBaroMs = now;
      filteredAGL = alt.update(baroAGL, dtS);
      velocityMps = alt.velocity;
      altReady = true;
    }
    const bool fresh = altReady && (uint32_t)(now - lastBaroMs) <= BARO_FRESH_MAX_MS;

    if (phase == Phase::PAD) {
      if (newAccel && isfinite(accelDeltaG)) {
        lastAccelMs = now;
        if (accelDeltaG >= ACCEL_LAUNCH_DELTA_G) {
          if (!accelStartValid) { accelStart = now; accelStartValid = true; }
        } else accelStartValid = false;
      }
      if (baroValid) {
        if (filteredAGL >= BARO_LAUNCH_RISE_M) {
          if (!baroStartValid) { baroStart = now; baroStartValid = true; }
        } else baroStartValid = false;
      }
      r.launchAccel = accelStartValid && newAccel &&
                      (uint32_t)(now - lastAccelMs) <= ACCEL_FRESH_MAX_MS &&
                      (uint32_t)(now - accelStart) >= ACCEL_LAUNCH_DWELL_MS;
      r.launchBaro = baroStartValid && baroValid && fresh &&
                     (uint32_t)(now - baroStart) >= BARO_LAUNCH_DWELL_MS;
      if (r.launchAccel || r.launchBaro) {
        phase = Phase::ASCENT;
        maxAGL = filteredAGL;
        peakSinceLaunch = filteredAGL;
        seenAscent = false;
        risingStartValid = false;
        // Keep prelaunch filter history, necessary for late baro launch detection.
        accelStartValid = baroStartValid = false;
      }
      return r;
    }
    if (phase == Phase::DONE || !fresh || !baroValid) return r;
    if (filteredAGL > peakSinceLaunch) peakSinceLaunch = filteredAGL;

    if (velocityMps >= RISING_VZ_MPS) {
      if (!risingStartValid) { risingStart = now; risingStartValid = true; }
      if ((uint32_t)(now - risingStart) >= ASCENT_SEEN_DWELL_MS) seenAscent = true;
    } else risingStartValid = false;

    if (!detectAllowed) {
      // Peak restarts from the current altitude once the lockout ends, so a
      // spike inside the lockout cannot look like a 3 m drop afterwards.
      maxAGL = filteredAGL;
      negStartValid = dropStartValid = floorStartValid = false;
      return r;
    }

    // Launch detected, lockout over, but no real climb: go through the flight
    // anyway. Drogue is due now; main is due too (the vehicle is below its
    // altitude) and the sketch spaces it by the drogue->main gap.
    if (phase == Phase::ASCENT && peakSinceLaunch < MIN_APOGEE_AGL_M) {
      phase = Phase::DESCENT;
      r.apogee = true;
      r.apogeeMethod = ApogeeMethod::NO_CLIMB;
      r.drogueDue = true;
    }
    if (filteredAGL > maxAGL) maxAGL = filteredAGL;
    const bool leftPad = maxAGL >= MIN_APOGEE_AGL_M;

    bool negative = seenAscent && leftPad && velocityMps <= FALLING_VZ_MPS;
    if (negative) {
      if (!negStartValid) { negStart = now; negStartValid = true; }
    } else negStartValid = false;
    bool reversal = negative && (uint32_t)(now - negStart) >= REVERSAL_DWELL_MS;

    bool belowPeak = leftPad && maxAGL - filteredAGL >= APOGEE_DROP_M;
    if (belowPeak) {
      if (!dropStartValid) { dropStart = now; dropStartValid = true; }
    } else dropStartValid = false;
    bool drop = belowPeak && (uint32_t)(now - dropStart) >= APOGEE_DROP_DWELL_MS;

    if (phase == Phase::ASCENT && (drop || reversal)) {
      phase = Phase::DESCENT;
      r.apogee = true;
      r.apogeeMethod = drop ? ApogeeMethod::PEAK_DROP : ApogeeMethod::VZ_REVERSAL;
      r.drogueDue = true;
    }

    if (!mainAccepted) {
      bool descending = phase == Phase::DESCENT || drop || reversal;
      // An independent crossing of the selected main altitude can still
      // request main even if a drogue request was rejected or normal apogee
      // logic stalls. Uses the profile altitude (>= 100 m), not a fixed 200 m,
      // so a lower main setting is not overridden by the backstop.
      const float mainTarget = target(programmedMain);
      bool floorCross = maxAGL >= mainTarget + FLOOR_CROSS_MIN_PEAK_M &&
                        filteredAGL <= mainTarget && velocityMps < 0.0f;
      if (floorCross) {
        if (!floorStartValid) { floorStart = now; floorStartValid = true; }
      } else floorStartValid = false;
      bool floorConfirmed = floorCross && (uint32_t)(now - floorStart) >= FLOOR_CROSS_DWELL_MS;
      r.mainDue = (descending && filteredAGL <= target(programmedMain)) || floorConfirmed;
      r.hardFloorDue = floorConfirmed;
    }
    return r;
  }

  void markMainAccepted() { mainAccepted = true; phase = Phase::DONE; }
  void forceLaunch(float startingAltitude) {
    phase = Phase::ASCENT;
    if (!altReady) { altReady = true; alt.reset(startingAltitude); filteredAGL = startingAltitude; }
    maxAGL = filteredAGL;
    peakSinceLaunch = filteredAGL;
    seenAscent = false;
    risingStartValid = false;
    accelStartValid = baroStartValid = false;
  }

private:
  comet_alt::Filter alt;
  bool altReady = false;
  uint32_t lastBaroMs = 0;
  uint32_t lastAccelMs = 0;
  uint32_t accelStart = 0, baroStart = 0, negStart = 0, dropStart = 0, floorStart = 0, risingStart = 0;
  bool accelStartValid = false, baroStartValid = false;
  bool negStartValid = false, dropStartValid = false, floorStartValid = false, risingStartValid = false;
};
} // namespace comet_recovery
