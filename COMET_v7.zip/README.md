# COMET v7 — firmware + GUI

```
COMET_Rolling_Recovery_v7/        <- open this folder in the Arduino IDE
  COMET_Rolling_Recovery_v7.ino   main sketch (from v6, changes listed below)
  SimpleRecoveryLogic.h           launch / apogee / main decisions + the altitude filter
  AltitudeFilter.h                median-3 + alpha-beta-gamma filter, pad GroundTracker
  LandingDetector.h               decides when the flight log can close
  OptionalBackupTimers.h          unchanged from v6
COMET_GUI_V3.py                   desktop GUI (pip install pyserial)
tools/replay.cpp                  replay a CSV log through the logic on a PC
bench_log.csv                     your 2026-10-31 bench log, used by the replay tool
```

## Building

- Board core: Earle Philhower **Arduino-Pico** (tested with rp2040 6.3.1).
- Flash size: same as v6 (a layout with a LittleFS partition).
- Libraries: Adafruit MPL3115A2, Adafruit LSM6DS, Adafruit Unified Sensor, Adafruit BusIO.
- Verified: compiles with `--warnings all` and no warnings
  (136 KB flash, 14.8 KB RAM, about the same as v6).

Existing logs and settings carry over. The log header layout and `LOG_VERSION` did not
change. On the first boot, v7 scans each older flight once to fill in its
max-altitude, max-g and max-speed numbers.

## What changed from v6

| Problem seen in the bench log | v7 change |
|---|---|
| Log never closed: it sat in MAIN_DEPLOYED for 161 s | v6 needed every altitude sample within 2 m of the *first* sample for 15 s, and the ~2.2 m baro noise kept resetting it. `LandingDetector.h` compares **1-second averages** instead: they must stay within 2 m over 5 s, with the IMU still for 3 s. If the IMU is moving, altitude alone for 20 s is enough. A 20-minute timeout guarantees the log always closes. Your log now closes 12 s after launch. |
| Baro noise, double filtering | The altitude was filtered twice, in the sketch and again in the logic, and Vz came from an 8-sample difference. Now there is **one** filter: median-3 followed by alpha-beta-gamma. Vz noise drops from 0.55 to 0.34 m/s, and apogee is detected about 0.5 s sooner. |
| Pad altitude read −4 m | The ground reference was set once at boot. `GroundTracker` now follows slow pressure drift while IDLE, freezes 2–3 s before launch, and re-zeroes on RESET. |
| Drogue **and main** were called on the bench at −4 m | After the shake-triggered launch, baro noise alone looked like an apogee. Apogee now also requires the peak to reach 10 m AGL and Vz above +1 m/s for 300 ms. |
| Hard to tell flights apart | Each flight header now stores max altitude, max \|a\| (sampled at 100 Hz) and max \|Vz\|. `LIST` prints `MAXALT= MAXG= MAXV=`. |

New log event notes: `LANDED_BARO_ONLY` (20) and `LOG_TIMEOUT` (21).
`GETPARAMS` now also reports `BARO_FILTER`, `GROUND_REF_M`, `MIN_APOGEE_AGL_M`,
`LANDING_SPREAD_M` and `LOG_TIMEOUT_S`.

## GUI (COMET_GUI_V3.py)

- Flight Logs tab: new **Max Alt / Max G / Max Speed** columns. Click any header
  to sort, and click again to reverse. Flights from older firmware show "—".
- The barometer plot shows live noise (σ and span). Leave the board still to read
  the sensor's noise floor.

## Replay tool

```bash
cd tools && g++ -std=c++17 -O1 replay.cpp -o replay && ./replay ../bench_log.csv
```

## Before flight

`PYRO_OUTPUTS_ENABLED` is still `false`. The changes to apogee, the filter and the
ground reference all affect when charges fire. Bench-test both channels with
igniters disconnected first: RESET → LAUNCH → shake → leave still, and check that
nothing fires and the log closes. Then check against OpenRocket or a recorded flight.

The MPL3115A2 at 16x oversampling is the remaining noise floor (about 0.4 m).
Foam over the sensor (to block light and airflow) and good static ports help most.
A BMP390 or MS5611 would cut the noise several-fold.
