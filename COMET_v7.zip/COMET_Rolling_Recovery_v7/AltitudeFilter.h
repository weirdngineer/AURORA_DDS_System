#pragma once
// COMET diagnostic altitude filter. No pins, sensor calls or heap allocations.
// Median of up to 3 genuinely new baro measurements -> alpha-beta-gamma tracker.
// The median suppresses isolated barometer spikes; the alpha-beta-gamma stage
// produces altitude AND vertical speed from one filter. It models constant
// acceleration, so coasting at -1 g does not bias vz (a plain IIR or
// alpha-beta lags several m/s there and delays VZ_REVERSAL apogee).
// Development only: verify altitude lag against OpenRocket and sensor replay
// before flight.
#include <math.h>
#include <stdint.h>
namespace comet_alt {

// Tuned on bench log noise (~0.4 m sd, strongly correlated) at ~10 Hz versus
// the old IIR 0.4 + 8-point difference: stationary vz noise sd 0.55 -> 0.34
// m/s (peak 1.8 -> 1.0), VZ_REVERSAL apogee delay on a synthetic coast
// 0.92 -> 0.38 s. Re-tune if the baro rate changes.
constexpr float ABG_ALPHA = 0.25f;
constexpr float ABG_BETA = 0.025f;
constexpr float ABG_GAMMA = 0.001f;
constexpr float DT_MIN_S = 0.02f;
constexpr float DT_MAX_S = 0.50f;  // longer gaps re-anchor instead of integrating

struct Filter {
  float history[3] = {};
  float output = 0;   // filtered altitude, m
  float velocity = 0; // filtered vertical speed, m/s (positive up)
  float accel = 0;    // filtered vertical acceleration, m/s^2 (internal)
  uint8_t used = 0;
  uint8_t index = 0;
  bool ready = false;
  void reset(float initial) {
    output = initial;
    velocity = 0;
    accel = 0;
    for (uint8_t i=0;i<3;i++) history[i] = initial;
    used=0; index=0; ready=true;
  }
  // Legacy call: assumes the nominal 10 Hz baro rate.
  float update(float raw) { return update(raw, 0.1f); }
  float update(float raw, float dtS) {
    if (!isfinite(raw)) return output;
    if (!ready) { reset(raw); return output; }
    history[index]=raw;
    index=(uint8_t)((index+1)%3);
    if (used<3) used++;
    float median=raw;
    if (used==3) {
      const float a=history[0],b=history[1],c=history[2];
      median = fmaxf(fminf(a,b),fminf(fmaxf(a,b),c));
    }
    if (!(dtS >= DT_MIN_S)) dtS = DT_MIN_S;
    if (dtS > DT_MAX_S) {  // sensor dropout: re-anchor instead of extrapolating
      // Re-seed vz from the gap; zeroing it would take seconds to recover at
      // these gains and could look like a reversal mid-flight.
      if (dtS < 5.0f) velocity = (median - output) / dtS;
      else velocity = 0;
      output = median; accel = 0;
      for (uint8_t i=0;i<3;i++) history[i] = median;
      used = 0;
      return output;
    }
    const float predicted = output + velocity * dtS + 0.5f * accel * dtS * dtS;
    const float residual = median - predicted;
    output = predicted + ABG_ALPHA * residual;
    velocity += accel * dtS + (ABG_BETA / dtS) * residual;
    accel += (2.0f * ABG_GAMMA / (dtS * dtS)) * residual;
    return output;
  }
};

// Tracks pad (ground) pressure-altitude while sitting on the pad so weather
// and sensor warm-up drift do not show up as a few metres of negative AGL
// (bench log sat at -4 m). Freeze it at launch using the snapshot from
// ~2-3 s earlier so the launch transient itself is never absorbed.
struct GroundTracker {
  static constexpr float TAU_S = 30.0f;
  float ground = 0;
  bool ready = false;
  float snap[3] = {};      // 1 s snapshots, oldest overwritten
  uint8_t snapIdx = 0;
  uint32_t lastSnapMs = 0;
  void reset(float rawAlt, uint32_t now) {
    ground = rawAlt; ready = true;
    for (uint8_t i=0;i<3;i++) snap[i] = rawAlt;
    snapIdx = 0; lastSnapMs = now;
  }
  // Call with RAW (unfiltered, un-zeroed) baro altitude only while on the pad.
  void update(float rawAlt, float dtS, uint32_t now) {
    if (!isfinite(rawAlt)) return;
    if (!ready) { reset(rawAlt, now); return; }
    if (dtS > 0 && dtS < 1.0f) ground += (dtS / (TAU_S + dtS)) * (rawAlt - ground);
    if ((uint32_t)(now - lastSnapMs) >= 1000u) {
      snap[snapIdx] = ground; snapIdx = (uint8_t)((snapIdx + 1) % 3); lastSnapMs = now;
    }
  }
  // Oldest snapshot: ground level from 2-3 s before launch was detected.
  float groundAtLaunch() const { return snap[snapIdx]; }
};
}
