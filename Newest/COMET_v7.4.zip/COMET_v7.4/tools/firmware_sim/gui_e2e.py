"""COMET GUI <-> simulated firmware end-to-end test over a pseudo-terminal."""
# Needs: ./run_all.sh first (creates img.bin), pyserial, a display (or xvfb-run).
import sys, time, subprocess, importlib.util, tempfile, shutil
from pathlib import Path
import serial.tools.list_ports as lp
HS = Path(__file__).parent
shutil.copy(HS / "img.bin", HS / "imgGUI.bin")
sim = subprocess.Popen([str(HS / "sim"), "interactive", str(HS / "imgGUI.bin"), "170"], stdout=subprocess.PIPE, text=True)
line = sim.stdout.readline()
while not line.startswith("PTY "):
    line = sim.stdout.readline()
pty = line.split()[1]

class FakePort:
    def __init__(self, dev): self.device, self.description, self.manufacturer, self.product = dev, "RP2040", "Generic", "RP2040"; self.hwid = "USB VID:PID=2E8A:F00A"; self.vid = 0x2E8A
plugged = {"on": True}
other = type("P", (), dict(device="/dev/ttyS0", description="n/a", manufacturer=None, product=None, hwid="n/a", vid=None))()
lp.comports = lambda: ([other, FakePort(pty)] if plugged["on"] else [other])

spec = importlib.util.spec_from_file_location("gui", str(Path(__file__).resolve().parents[2] / "COMET_GUI.py"))
g = importlib.util.module_from_spec(spec); sys.modules["gui"] = g; spec.loader.exec_module(g)
dialogs = []
g.ask_yes_no = lambda app, title, msg, **k: (dialogs.append(title), True)[1]
g.show_info = lambda app, title, msg, parent=None: dialogs.append(title)
g.show_error = lambda app, title, msg, parent=None: dialogs.append("ERROR:" + title)
g.message_box = lambda app, title, msg, buttons, **k: (dialogs.append(title), False)[1]
out = Path(tempfile.mkdtemp())
g.csv_save_dialog = lambda app, title, name: str(out / name)
g.choose_folder = lambda app, start, parent=None, title="": str(out)

import tkinter as tk
root = tk.Tk(); g.pick_fonts(root); app = g.COMETApp(root)
g.install(app)  # flight-log plotter, exactly as main() does
console = []
_cw = app.console_write
app.console_write = lambda text, tag=None: (console.append((round(time.monotonic(), 1), text.strip())), _cw(text, tag))[1]
results = []
def ok(cond, what): results.append((bool(cond), what)); print(f"  [{'PASS' if cond else 'FAIL'}] {what}", flush=True)

def newest_saved_flight():
    rows = [r for r in app.log_rows.values() if r["kind"] == "FLIGHT" and r["status_code"] == 2]
    return max(rows, key=lambda r: r["id"]) if rows else None

state = {}
def act_edit():
    app.select_profile("VIOLET")
    app.alt_var.set("150"); app.lockout_var.set("4"); app.gap_var.set("2")
    app.dtimer_var.set(True); app.dtimer_s_var.set("14"); app.mtimer_var.set(True); app.mtimer_s_var.set("20")
    app.apogee_delay_var.set("1.5"); app.main_delay_var.set("0.7")
    app.profiles["VIOLET"]["alt_m"] = 0  # make sure the value we check comes back from the board
    app.save_profile()
def act_revert():
    app.select_profile("VIOLET")
    app.alt_var.set("200"); app.lockout_var.set("6"); app.gap_var.set("3")
    app.dtimer_var.set(False); app.mtimer_var.set(False)
    app.apogee_delay_var.set("0"); app.main_delay_var.set("0"); app.save_profile()
def act_download():
    r = newest_saved_flight(); state["dl"] = r
    if r is None: return
    app.log_tree.selection_set(f"FLIGHT:{r['slot']}"); app.download_selected()
def act_launch():
    state["flights_before"] = sum(1 for r in app.log_rows.values() if r["kind"] == "FLIGHT")
    app.send_command(f"PROFILE SET {app.active_profile} APOGEE_DELAY_MS 2000")  # pop test with drogue +2 s
    root.after(600, lambda: app.confirm_command("LAUNCH", "Force Launch", "test"))
def plot_windows():
    return [w for w in root.winfo_children() if isinstance(w, g.FlightPlotWindow)]
def act_plot():
    newest = max((r for r in app.log_rows.values() if r["kind"] == "FLIGHT"), key=lambda r: r["id"])
    app.log_tree.selection_set(f"FLIGHT:{newest['slot']}")
    g.plot_selected(app)
def act_unplug(): plugged["on"] = False
def act_replug(): plugged["on"] = True
VP = lambda: app.profiles["VIOLET"]
steps = [
    ("auto-connects to the RP2040 port (ignores /dev/ttyS0)", None, lambda: app.is_connected() and app.ser.port == pty, 10),
    ("firmware version shown", None, lambda: app.fw_version == "7.4" and "firmware 7.4" in app.fw_var.get(), 10),
    ("profiles loaded; editor follows active profile", None, lambda: app.active_profile and app.selected_profile == app.active_profile and VP()["lockout_s"] == 6.0, 10),
    ("log list loaded with flight stats", None, lambda: sum(1 for r in app.log_rows.values() if r["kind"] == "FLIGHT" and r["max_alt"]) >= 3, 10),
    ("outputs LIVE by default (card)", None, lambda: app.pyro_live is True and app.card_vars["OUTPUTS"].get() == "LIVE", 5),
    ("save profile round-trips through the board", act_edit, lambda: VP()["alt_m"] == 150 and VP()["lockout_s"] == 4 and VP()["gap_s"] == 2 and VP()["dtimer"] and VP()["mtimer"] and VP()["dtimer_s"] == 14 and VP()["mtimer_s"] == 20 and VP()["apogee_delay_s"] == 1.5 and VP()["main_delay_s"] == 0.7, 8),
    ("profile reverted to defaults", act_revert, lambda: VP()["alt_m"] == 200 and VP()["lockout_s"] == 6 and not VP()["dtimer"] and not VP()["mtimer"] and VP()["gap_s"] == 3 and VP()["apogee_delay_s"] == 0, 8),
    ("Make SAFE", lambda: app.disarm_pyro(), lambda: app.pyro_live is False and app.card_vars["OUTPUTS"].get() == "SAFE", 5),
    ("Enable LIVE (one confirm, no typing)", lambda: app.arm_pyro(), lambda: app.pyro_live is True, 5),
    ("download newest flight CSV", act_download, lambda: app.dl is None and any(out.glob("*.csv")), 30),
    ("downloaded flight marked Downloaded on the board", None, lambda: app.log_rows.get(f"FLIGHT:{state['dl']['slot']}", {}).get("status_code") == 3, 8),
    ("export all", lambda: app.export_all(), lambda: app.dl is None and len(list(out.glob("COMET_export_*/*.csv"))) >= 4, 60),
    ("force launch -> lockout countdown on STATE card", act_launch, lambda: app.card_vars["STATE"].get().startswith("LOCKOUT"), 5),
    ("DROGUE card counts down during the +T delay", None, lambda: app.card_vars["DROGUE"].get().startswith("in "), 12),
    ("board reaches LANDED on its own", None, lambda: app.last_telemetry.get("STATE") == "LANDED", 45),
    ("pop test: DROGUE and MAIN cards show FIRED", None, lambda: app.card_vars["DROGUE"].get() == "FIRED" and app.card_vars["MAIN"].get() == "FIRED", 3),
    ("LIST after landing works without RESET (new flight listed, >= 30 s)", lambda: app.send_command("LIST"), lambda: any(r["kind"] == "FLIGHT" and r["newest"] and r["seconds"] >= 30 for r in app.log_rows.values()) and "Board Is in Flight Mode" not in dialogs, 6),
    ("Plot Selected: newest flight plotted from the board", act_plot,
        lambda: plot_windows() and app.dl is None, 15),
    ("plot summary measures the 2 s drogue delay and the 3 s gap", None,
        lambda: abs(plot_windows()[-1].a.stats.get("trigger_to_drogue", -9) - 2.0) < 0.15
                and abs(plot_windows()[-1].a.stats.get("drogue_to_main", -9) - 3.0) < 0.15, 3),
    ("settings change after landing -> GUI offers Reset to IDLE", lambda: app.arm_pyro(), lambda: "Board Is in Flight Mode" in dialogs and app.last_telemetry.get("STATE") == "IDLE", 8),
    ("manual Disconnect is respected (no instant reconnect)", lambda: app.toggle_connection(), lambda: not app.is_connected(), 3),
    ("... still disconnected 3 s later", None, None, 3),
    ("unplug", act_unplug, lambda: app.auto_suppressed is None, 6),
    ("replug -> reconnects automatically", act_replug, lambda: app.is_connected(), 8),
    ("imperial units in the log table", lambda: (app.unit_mode.set(1), app.on_unit_change()), lambda: any(" ft" in str(app.log_tree.item(i, "values")[5]) for i in app.log_tree.get_children()), 3),
]
idx = {"i": 0, "t": time.monotonic(), "acted": False}
def tick():
    if idx["i"] >= len(steps):
        root.quit(); return
    name, action, cond, timeout = steps[idx["i"]]
    if not idx["acted"]:
        idx["acted"] = True; idx["t"] = time.monotonic()
        if action: action()
    elapsed = time.monotonic() - idx["t"]
    if cond is None:
        if elapsed >= timeout:
            ok(not app.is_connected(), name); idx.update(i=idx["i"] + 1, acted=False)
    elif cond():
        ok(True, name); idx.update(i=idx["i"] + 1, acted=False)
    elif elapsed > timeout:
        ok(False, name + f"  (timed out after {timeout}s)"); idx.update(i=idx["i"] + 1, acted=False)
    root.after(100, tick)
root.after(500, tick)
root.mainloop()
csvs = list(out.glob("*.csv"))
if csvs:
    txt = csvs[0].read_text().splitlines()
    ok(txt[0].startswith("t_ms,state,state_name") and len(txt) > 300, f"downloaded CSV has header + {len(txt) - 1} rows")
print("  dialogs seen:", dialogs)
Path("gui_console.txt").write_text("\n".join(f"{t} {c}" for t, c in console if c and not c.startswith("DATA")))
li = [i for i, c in enumerate(console) if c[1].startswith(">>> LAUNCH")]
if li:
    print("  board console around the forced launch:")
    for t, c in console[li[0]: li[0] + 25]:
        if c and not c.startswith("DATA"): print("    ", t, c[:120])
app.disconnect(); root.destroy(); sim.terminate()
fails = sum(1 for r in results if not r[0]); print(f"  -> {len(results) - fails} passed, {fails} failed")
sys.exit(1 if fails else 0)
