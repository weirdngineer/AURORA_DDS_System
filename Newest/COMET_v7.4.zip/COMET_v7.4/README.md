# COMET 7.4 — flight computer + ground station

COMET is a dual-deploy recovery computer (drogue at apogee, main at a set altitude).
This folder holds everything you need to set it up, fly it, and send back flight data.

```
Start COMET (Windows).bat       double-click to start the app on Windows
start_comet_gui_linux.sh        start the app on Linux (first time: --setup)
COMET_GUI.py                    the app itself (Python 3 + pyserial), with the flight-log plotter
firmware/COMET_Firmware.uf2     ready-to-install firmware
firmware/COMET_Firmware/        firmware source (Arduino sketch + headers)
linux/99-comet-rp2040.rules     Linux USB permission rule (installed by --setup)
tools/                          developer tools: log replay + whole-firmware simulator
```

---

## 1. Start the app

**Windows 10/11:** install Python 3 from python.org once. Tick **"Add python.exe to PATH"**
during the install. Then double-click **`Start COMET (Windows).bat`**. The first launch
installs `pyserial` automatically.

**Linux:** run these once:

```bash
sudo apt install python3-tk
```

```bash
./start_comet_gui_linux.sh --setup
```

The second command installs a USB rule so you don't need `sudo` or the `dialout` group,
and it stops ModemManager from poking at the board. After that, start the app with:

```bash
./start_comet_gui_linux.sh
```

**Plug the flight computer in over USB.** The app finds it by itself and connects: a
`COMx` port on Windows, `/dev/ttyACM0` on Linux. It also reconnects after you unplug and
replug. You don't need to pick a port unless you have several boards connected. Use a
data USB cable; charge-only cables are a common cause of "nothing happens".

## 2. Set up a flight (Flight Setup tab)

1. **Pick a profile colour** on the left. These are the colours on the board's LED, and
   the board's **MODE** button cycles through them.
2. Edit the profile and press **Save to Board**.
3. Press **Make This the Active Profile**, or use the MODE button on the board.

| Setting | Default | What it does / how to choose |
|---|---|---|
| Main parachute altitude | 200 m | Height above the pad where the main fires on the way down. Allowed range 100 – 10000 m. |
| Detect launch with accelerometer | on | Launch is detected at ≥1.2 g above rest for 0.1 s. The barometer also detects launch on its own once the rocket is 30 m up. |
| **Safety lockout after launch** | **6 s** | Nothing is detected or fired for this long after launch. This covers Mach effects on the barometer and bumped launches. **Set it longer than the motor burn plus about 1 s, and shorter than the time to apogee** (check OpenRocket). |
| Minimum drogue → main gap | 3 s | Shortest time allowed between the drogue and main charges, whatever triggered them. Main never fires before drogue + gap. |
| Drogue delay (+T) | 0 s | The drogue fires this long after *any* drogue trigger: barometric apogee, the no-climb sequence or the drogue timer. 0 – 30 s in 0.1 s steps. |
| Main delay (+T) | 0 s | The main fires this long after *any* main trigger: altitude crossing, backstop or main timer. It still also waits for drogue + gap. 0 – 30 s in 0.1 s steps. |
| Drogue backup timer | off (15 s) | Fires the drogue this many seconds after launch if the barometer hasn't already. |
| Main backup timer | off (25 s) | Fires the main this many seconds after launch, but only after a drogue command. With both timers on, main must be at least 2 s after drogue. |

> **Small motors.** If apogee comes in under about 7 s, apogee happens *inside* a 6 s
> lockout, so recovery starts late. In simulation, a 77 m flight with the defaults fired
> its main on the ground. With **lockout 2 s and gap 1 s** the drogue fired 0.7 s after
> apogee and the main at 58 m.

### What happens after a launch is detected
A detected launch **always runs the full flight sequence**:
- **Real flight** (the barometer sees at least 10 m of climb): the drogue fires at
  barometric apogee, then the main at its altitude on the way down.
- **No climb by the end of the lockout** (pop test, a dropped or bumped rocket, a hop):
  the **drogue fires when the lockout ends** and the **main follows after the
  drogue → main gap**. With the defaults that's drogue at +6 s and main at +9 s. Any
  drogue / main delays (+T) are added on top: with drogue +1.5 s and the 3 s gap, the
  drogue fires at +7.5 s and the main at +10.5 s.

So with outputs LIVE, a launch detected on the pad *will* fire both charges. To cancel,
power the board off or press **Reset to IDLE** within the lockout.

Every flight log runs **at least 30 s** after launch, and longer while the board is still
moving.

### Pyro outputs
**LIVE (the default)** means the drogue and main MOSFETs really fire. **Make SAFE (bench)**
keeps the flight logic and logging running but never switches the outputs, which is useful
for testing. The choice is saved on the board. A LIVE board plays **3 long high tones** at
power-up.

## 3. At the pad: what the beeps mean

| Sound / light | Meaning |
|---|---|
| Rising 4-note melody | Powered on |
| 2 beeps | Sensors OK |
| **Alternating alarm for ~5 s, LED red** | **Barometer failed — do not fly** (alarm with the LED in its profile colour = IMU failed; barometer-only launch detection) |
| **3 long high tones** | **Pyro outputs LIVE** |
| Short chirp every 2 s | Waiting for launch (IDLE). This is *not* a continuity check. |
| Rapid beeping for 3 s | Launch detected |
| 1 s rapid beeping | A pyro channel is firing |
| LED blinking yellow | Log storage full. Download your logs, or hold MODE for 5 s to erase the oldest flight. |

Launch detection needs at least 1.2 g above rest held for a full 0.1 s. Big swings or a
sharp upward jerk trigger it; small fast jiggling does not. If a launch is detected by
mistake, you have the lockout (6 s by default) to power off or press **Reset to IDLE**.
After that, the drogue and then the main fire.

### Pop testing in flight configuration
Leave the board exactly as it will fly: flight profile, outputs LIVE, charges installed.
There are two ways to start the test:
- **From the app:** press **Force Launch** in Flight Setup.
- **No laptop:** give the board a big swing or sharp upward jerk until the launch beeps
  start.

After the lockout (plus any drogue delay) the drogue fires, then the main after the gap. The test is **logged as a
flight** (at least 30 s), so you can download it like any other. After it reaches LANDED,
power-cycle the board or press Reset to IDLE before the next test or flight.

**Test Drogue / Test Main** fire one channel immediately, and that firing is not logged.

## 4. After the flight: send the data back

1. Plug the board into USB. It can stay powered from its battery. Once it has landed it
   shows **LANDED**, and logs can be downloaded straight away with no reset needed.
2. Open **Flight Logs**. Each flight shows **Max Alt / Max G / Max Speed**, so you can tell
   flights apart. Click a column header to sort.
3. Press **Export All** and pick a folder. Every log is saved into a new `COMET_export_…`
   folder, and the flights are marked **Downloaded** on the board.
4. Zip that folder and send it back, along with the motor, rocket and any notes.

To look at a flight, use **Plot Selected** (or double-click a log), or **Open CSV...** for
a saved file. It shows:
- altitude and speed, acceleration and gyro, with launch, apogee, drogue and main marked
  and the MOSFET on-time shaded,
- a flight summary, including the measured **trigger → drogue** delay and
  **drogue → main** gap, so you can confirm your +T settings in a real log.

The board keeps 20 flights. When it needs room, it erases the oldest *completed* flight
first.

## 5. Update the firmware

Go to **Flight Setup → Update Firmware…**. The board restarts into its update mode, the app
copies `firmware/COMET_Firmware.uf2` across, and then reconnects by itself. Saved profiles
and flight logs are kept.

If that doesn't work:
1. Unplug the board.
2. Hold its **BOOTSEL** button while plugging it back in.
3. Copy `COMET_Firmware.uf2` onto the **RPI-RP2** drive that appears.

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| App never connects | Try a different (data) USB cable. On Linux, run `./start_comet_gui_linux.sh --setup` and replug. On Windows, close the Arduino IDE Serial Monitor, since only one program can use the port. |
| "Board is in flight mode" | The board thinks it is flying. If the rocket is on the ground, accept **Reset to IDLE**. |
| "Log storage not ready" | Storage was laid out by a different firmware. **Format Storage** fixes it, but erases what is there. |
| "update recommended" next to the firmware version | Use **Update Firmware…**. |

## 7. Known limitations

- **Brown-out resets.** If the battery voltage dips when a charge fires and the board
  resets mid-flight, it restarts in IDLE and won't fire the remaining channel. Use a
  battery that can supply the igniter current (or a separate pyro battery or capacitor).
  The log is saved every 2 s, so at most about 2 s of data is lost.
- **Max Speed is barometer-based.** Transonic pressure effects can inflate it.
- **Barometer noise.** The MPL3115A2 is the noise floor, about 0.4 m. Foam over the sensor
  and proper static ports help.

---

## For developers

**Build (Arduino IDE)**
- Earle Philhower *Raspberry Pi Pico/RP2040* core.
- Board **Generic RP2040**.
- **Flash Size: 16MB (Sketch: 1MB, FS: 15MB)**. The prebuilt UF2 uses exactly this.
  Changing the flash size moves the log storage, so download logs before you change it.
- Libraries: Adafruit MPL3115A2, Adafruit LSM6DS, Adafruit Unified Sensor, Adafruit BusIO.

**Verification shipped in `tools/`**
- `replay.cpp` replays any CSV log, plus synthetic flights, through the recovery logic:

  ```bash
  cd tools && g++ -std=c++17 -O1 replay.cpp -o replay && ./replay bench_log_2026-10-31.csv
  ```

- `firmware_sim/` compiles the **real `COMET_Firmware.ino`** on a PC against simulated
  hardware (Linux/WSL):
  - an MPL3115A2 emulated at the register level, plus the IMU,
  - flash storage that survives simulated power cuts,
  - a UART that models the 57600-baud FIFO,
  - a rocket whose parachutes open only when the MOSFET pins actually switch.

  `./run_all.sh` flies 23 scenarios with 171 checks. They include:
  - a normal flight, a transonic glitch, 100 m main, barometer-only launch,
  - low flights, a hop, a pad bump with timers on,
  - a forced launch, swinging and shaking the board,
  - drogue / main +T delays (pop test, real flight, delayed drogue with main waiting),
  - SAFE mode, a power cut with recovery,
  - settings migration from v5 and v6 files, and corrupted storage.

  `gui_e2e.py` then drives the real GUI against the simulated board over a virtual
  serial port (24 checks).

**v7.4 changes from v7.3**
- **Drogue delay and main delay (+T), per profile, default 0.** Each one applies to every
  trigger of its channel. Main never fires before a queued drogue plus the gap, even
  while the drogue is waiting out its delay.
- **Countdown on the cards:** the GUI's DROGUE / MAIN cards show "in 1.5s" while a
  delayed charge is waiting.
- **Settings format v7.** Profiles saved by older firmware carry over with both delays at
  0. The GUI only sends the delay fields to boards running 7.4 or newer.
- **Flight-log plotter (Plot Selected / Open CSV...)** is now part of the app. Its summary
  measures the trigger → drogue delay and the drogue → main gap. It recognises the
  no-climb pop-test trigger, and dates notes that share a moment to when it happened.

**v7.3 changes from v7.2**
- **A detected launch always runs the flight sequence.** If there's no climb by the end of
  the lockout, the drogue fires then and the main after the gap. Real flights are
  unchanged.
- **Flight logs run at least 30 s.** Timer backups no longer wait for a 10 m climb.
- **Events in the same 100 ms are no longer lost.** Each log record holds one event, and
  until now any others at the same moment (e.g. apogee + drogue) were overwritten. They
  are now queued.

**v7.2 changes from v6 (summary)**
- **Barometer path:** one altitude filter (median-3 + alpha-beta-gamma), velocity noise
  −40%, apogee about 0.5 s sooner. The pad zero now tracks pressure drift.
- **Barometric apogee needs a 10 m climb:** on the bench, baro noise after a
  shake-triggered launch used to fake an apogee. (Since v7.3 a no-climb launch fires
  deliberately at the end of the lockout instead.)
- **The lockout blocks detection,** not just firing.
- **Landing detection works:** it uses 1 s averages plus IMU stillness, so the log
  actually closes. There is also a 20 min timeout.
- **Pyro control:** outputs LIVE by default and switchable from the GUI. Separate drogue
  and main timers, main altitude down to 100 m, a configurable gap.
- **Radio no longer blocks the loop:** telemetry used to block it about 85% of the time.
  A blank board now formats its storage once. Bench tests no longer use up a channel.
- **Log access:** logs can be read after landing. Each log stores max altitude, g and
  speed. The log is saved every 2 s.
- **GUI:**
  - auto-connect and reconnect,
  - one-click firmware update,
  - drogue→main gap setting,
  - log statistics columns,
  - fits 1366×768 screens.
